# Reconciliation — Sales & Traffic / Settlements / Profit by SKU vs LIVE DataDoe Reports UI

Seller: **Vertex trading UK** (`19076074-9461-4eb0-a762-5f27185f9e5b`) · GBP.
Ranges: **July 1–31, 2026** and **August 1–28, 2026**.
Method: direct LIVE inspection of the DataDoe Reports UI via Claude-in-Chrome (React Query cache + nav enumeration). **DataDoe export tokens spent: 0. Sync: 0. Export: 0.**

## Step 1 — Enumerate EVERY LIVE Reports-UI report tab (authoritative)

The Reports UI exposes exactly **7 report tabs** (read from the live nav):
1. **Profit & Loss**
2. **PPC – Products**
3. **PPC – Campaigns**
4. **PPC – Targeting and Search Terms**
5. **Inventory**
6. **Orders**
7. **Search Query Performance (SQP)**

There is **no** tab named (or defined as) *Sales & Traffic*, *Settlements*, or *Profit by SKU*.

## Step 2 — Check whether the three datasets are represented under a different report name

Column schemas read directly from the LIVE app-API responses:

| LIVE report | Real columns (key) | Is it S&T / Settlements / Profit-by-SKU? |
|---|---|---|
| Profit & Loss | date, sales, units, refunds, promo, advertising_cost, shipping_costs, refund_cost, amazon_fees(+details incl. reversal_reimbursement, warehouse_damage_exception), cost_of_goods, **sessions**, net_profit, margin, tacos, **unit_session_percentage** | Carries sessions/units/sales/conversion AND settlement-ish components — but it is the **P&L** report, a different definition. Not a standalone S&T or Settlements report. |
| Orders | date, amazonOrderId, orderStatus, fulfillmentChannel, items[], address, orderTotals | Order-level list (paginated 100/page). Not an aggregated S&T report. |
| PPC – Products | childAsin, sku, adSpend, adSalesSameSku, **sales**, **quantity**, **orders**, **fee**, **cogsTotal**(=0), adUnitsSoldSameSku | Per-SKU sales/units/fee/ad — closest to Profit-by-SKU, BUT a **different definition** (see Step 3). No `profit` column; COGS not populated. |
| Inventory | stock levels | No. |
| SQP | search-query impressions/clicks/purchases | No. |

## Step 3 — Prove PPC-Products ≠ the dashboard's Profit-by-SKU (cannot substitute)

LIVE **PPC-Products** (Aug 1–28, 43 SKUs): total **sales £2,154.29** · units 168 · orders 162 · fee £1,011.66 · cogs £0 · adSpend £1,028.29. Top SKU B0B3RYSVD4: **sales £659.56**.

Backend **Profit-by-SKU** (source `Profit by SKU & Date`, Aug 1–28, 48 ASINs): total **revenue £2,001.84** (= P&L Sales) · profit £305.53 · adSpend £1,028.29. Top ASIN B0B3RYSVD4: **revenue £601.25**, profit £178.82.

→ Sales differ by **£152.45** in total and **£58.31** on the top SKU. The dashboard's Profit-by-SKU uses the P&L-consistent net sales (£2,001.84); PPC-Products uses a different (gross/attribution) sales basis (£2,154.29) and exposes no `profit`. **They are different report definitions**, so PPC-Products is NOT a valid verification basis for the dashboard's Profit-by-SKU (rules forbid substituting another report).

## Backend / dashboard values captured (for the record)

| Section | Source (export) | Jul 1–31 | Aug 1–28 |
|---|---|---|---|
| Sales & Traffic | Sales & Traffic by ASIN & Date | **not_synchronized** (leading gap 07-01..19 upstream-empty; dashboard shows "not available") | totalSales £1,796.61 · units 136 · orders 131 · sessions 7,012 · **partial** (missing 08-25..28) |
| Settlements | Settlements & P&L Components | netRevenue £1,683.86 (full) | netRevenue £367.07 (full) |
| Profit by SKU | Profit by SKU & Date | (48 ASINs) | revenue £2,001.84 · profit £305.53 · adSpend £1,028.29 |

## Determination

- **Sales & Traffic** — no corresponding LIVE Reports-UI report. Sessions / page-views / conversion appear ONLY inside the P&L report (a different definition). → **UNVERIFIED** (cannot substitute P&L).
- **Settlements** — no corresponding LIVE Reports-UI report. Settlement components (reimbursements, adjustments, fees, refunds) appear only embedded in P&L `*_details`. → **UNVERIFIED**.
- **Profit by SKU** — no corresponding LIVE Reports-UI report. The only per-SKU report (PPC-Products) uses a materially different sales definition (proven above). → **UNVERIFIED**.

**No fix applied** (no proven mismatch against a LIVE definition — there is no LIVE definition to reconcile against). **No Export** (the question is answered by the LIVE UI structure, read token-free). Substituting a different report or fabricating a value is explicitly disallowed.

## Note (observation, not a verified mismatch)

The `Profit by SKU & Date` source's `ad_spend` (£1,028.29) and the LIVE PPC-Products `adSpend` (£1,028.29) both predate the Aug PPC-Campaigns refresh (SP is now £1,044.75 at campaign level). Product-attributed ad spend is a distinct sub-total from campaign-level SP spend, and neither has a like-for-like LIVE report to verify the SKU figure against — so this is recorded as an observation, not a verified mismatch.

---

## FRESH independent re-verification — 2026-08-30 (later session; 0 tokens, 0 sync, 0 export, 0 code changes)

Re-ran the whole determination from scratch (not relying on the section above as proof).

**LIVE Reports-UI tab strip, re-read from the live DOM this session (authoritative):** `Profit & Loss · PPC – Products · PPC – Campaigns · PPC – Targeting and Search Terms · Inventory · Orders · Search Query Performance (SQP)` — exactly 7. **None** = Sales & Traffic, Settlements, or Profit by SKU. Screenshot: `evidence/2026-08-30_datadoe-reports-ui-7-tabs.jpg`.

**Data scheme page (`/data-scheme`), re-read this session:** "114 tables · 3 sources" (Seller Central 64 / Vendor Central 20 / Ads 30). The catalog DOES list the three underlying tables — `Sales & Traffic` (`amazon_sales_and_traffic_with_cogs`, 401ffcd7e5), `Settlements & P&L Components` (`amazon_settlements_with_cogs`, 732dac689a), `Profit by SKU & Date` (`amazon_profit_by_sku_and_date`, 57a0cb319c) — but this is a **schema reference "for queries, skills, and exports"**, not a report with values. Reading values from any of these tables requires running an Export (a token). Screenshot: `evidence/2026-08-30_datadoe-data-scheme-sources.jpg`.

**Conclusion (unchanged, freshly re-proven):** all three are valid **export sources** but have **no corresponding LIVE Report**. There is no token-free LIVE surface for their values. Verifying them against LIVE would require an Export of the source table — **STOPPED, not executed** (rules #: no Export/Sync). → **UNVERIFIED** (not PASS). P&L / Orders / PPC-Products carry overlapping fields but are different report definitions and may not be substituted.

**Internal chain (cache = backend = dashboard), verified for Aug 1–28 this session (the only verification possible without LIVE):**

| Section | Metric | Local cache (recomputed) | Backend API | Dashboard | Match |
|---|---|---|---|---|---|
| Sales & Traffic (partial→08-24) | gross sales | £1,796.61 | £1,796.61 | £1,797 | ✓ |
| | units | 136 | 136 | 136 | ✓ |
| | orders | 131 | 131 | 131 | ✓ |
| | sessions | 7,012 | 7,012 | 7,012 | ✓ |
| | AOV / unit-session% | £13.71 / 1.94% | £13.71 / 1.94% | £13.71 / 1.9% | ✓ |
| Settlements (full) | net revenue (Σ total) | £367.07 | £367.07 | £367 | ✓ |
| Profit by SKU (full) | ASIN count | 48 | 48 | 48 cards | ✓ |
| | revenue | £2,001.84 | £2,001.84 | Σ product cards | ✓ |
| | profit | £305.53 | £305.53 | per-card margins | ✓ |
| | ad spend | £1,028.29 | £1,028.29 | per-card AD SPEND | ✓ |

Cache-file isolation reconfirmed by mtime: S&T `60c14704` (15:23), Settlements `0c6ba485` (15:23), Profit-by-SKU `88e1cb18` (15:23) — none touched today; Ad-Performance `e3ada2b9` (00:01) and P&L archive (22:00) also untouched by this task.

**Regression — PPC & P&L unchanged:** dashboard PPC SPEND £1,045 and NET PROFIT £969 both still render (this session); their cache files carry no new mtime; no code/export/sync this task. ✓

**Honest-zero check:** S&T missing tail (08-25..28) renders "not available" / partial banner, never £0; Profit-by-SKU zero-revenue ASINs are genuine (real 0-revenue rows), not fabricated. ✓

---

## DEEP LIVE-APP sweep — 2026-08-31 (React Query + network-endpoint level; 0 export, 0 sync, 0 code)

Went beyond the tab strip: enumerated the live app's React Query cache and captured the actual report API endpoints (token-free session-cookie calls the app itself makes), plus P&L/Orders payload shapes, to test whether the three datasets are exposed ANYWHERE.

- **Report API endpoint pattern:** `https://api.datadoe.com/api/core/reports/<report>/details?...&contextId=<seller>`. Observed live: `profit-and-loss/details`, `ads/campaigns/details`, `orders/details` (paginated `page/limit`). By tab presence the full set is 7: profit-and-loss, ads/products, ads/campaigns, ads/targeting, inventory, orders, search-query-performance. **No `sales-and-traffic`, `settlements`, or `profit-by-sku` report endpoint exists.**
- **React Query cache** only ever holds the visited tab's report + app-shell queries (features/user/organization/contexts). No hidden S&T/Settlements/Profit-by-SKU data is preloaded anywhere.
- **P&L `/details` payload** (interval=MONTH, 1 bucket) rowKeys = date, sales, units, refunds, promo, advertising_cost(+details), shipping_costs, refund_cost(+details), amazon_fees(+details), cost_of_goods(+details), **sessions**, gross_profit, net_profit, estimated_payout, tacos, refund_rate, margin, roi, unit_session_percentage. **`hasAsinBreakdown: false`** — per-date only, NO per-ASIN and NO per-settlement-line rows → does NOT contain the Profit-by-SKU or Settlements datasets. Its `sessions` (7,012) equals our S&T-derived sessions upstream, but P&L `sales` £2,147.68 / `units` 166 ≠ our S&T `total_sales` £1,796.61 / `units` 136 (different basis + P&L covers full Aug vs S&T partial→08-24). Using P&L to "verify" S&T = inferring one dataset from another → disallowed.
- **Orders `/details` payload** rowKeys = date, amazonOrderId, merchantOrderId, orderStatus, fulfillmentChannel, items, address, orderTotals (paginated 100/page). Order-level transactions — not the Settlements settled-`total` aggregate, not S&T sessions, not per-ASIN profit.
- **Download CSV / Exports / Data scheme:** Download CSV exports the currently-displayed report (P&L/PPC/Orders/…), none of which is S&T/Settlements/Profit-by-SKU; Exports = past export snapshots (stale, token-gated to create); Data scheme = schema only. None yields token-free LIVE values for the three.

**Determination (deep sweep): all three remain UNVERIFIED — no corresponding LIVE report/endpoint anywhere in the live app.** To verify requires an Export of the source table (1 token each: `amazon_sales_and_traffic_with_cogs` / `amazon_settlements_with_cogs` / `amazon_profit_by_sku_and_date`, Aug 1–28). **NOT run** (rules F/G; not asking for speculative-export approval).

**Internal chain re-confirmed fresh (Aug 1–28):** S&T cache=backend £1,796.61/136/131/7,012 (AOV £13.71, USP 1.94%, partial→08-24); Settlements cache=backend netRev £367.07 (referral −£347.19, fba fulfil −£540.21, storage −£64.58, LT storage −£103.42, refunds −£89.85, promotions −£108.20); Profit-by-SKU cache=backend 48 ASINs/£2,001.84/£305.53/adSpend £1,028.29. (Raw recompute showed 49 keys = one null-`child_asin` £0 bucket the backend correctly drops.)

**Regression:** PPC Aug £1,044.23 (matches LIVE, closed) ✓; July PPC £1,015.58 ✓; P&L backend July £1,009.85 / Aug £968.80 — UNCHANGED, not broken by this task ✓. **OBSERVATION (out of scope, not fixed):** the LIVE P&L report has itself restated up since our static P&L archive (2026-08-29 22:00): LIVE now net_profit £1,104.87 / sales £2,147.68 (MONTH) vs our archived DAY-basis £968.80 / £2,001.84. Same restatement drift PPC had; P&L is internally consistent (cache=backend=dashboard £969) but stale vs current LIVE. Left untouched per "do not change P&L" — flagged for a future authorized P&L re-capture.

**DataDoe calls: 0. Sync: 0. Export: 0. Code changes: 0.**

---

## Token-free app-API PROBE — 2026-08-31 (decisive: no P&L-style endpoint exists for the three)

After P&L was successfully refreshed via its token-free app-API (`/api/core/reports/profit-and-loss/details`), the open question was whether S&T / Settlements / Profit-by-SKU have an analogous token-free endpoint. **Directly tested it** with a read-only, session-cookie `fetch` (credentials:'include') from the app origin — no token, no export, no mutation — against `api.datadoe.com/api/core/reports/<slug>/details` for 13 candidate slugs.

**Result (HTTP status):**
- `profit-and-loss` → **400** (endpoint EXISTS; my probe omitted comparison params — the app loads it fine, and I captured its data earlier). This is the control proving the probe distinguishes real endpoints.
- `sales-and-traffic`, `sales_and_traffic`, `sales-traffic`, `sales` → **404**
- `settlements`, `settlement`, `settlements-and-pnl`, `finances` → **404**
- `profit-by-sku`, `profit-by-sku-and-date`, `sku-profit`, `profit-per-sku` → **404**
- NONE returned a data array.

**Conclusion:** the 400-vs-404 contrast is decisive — the P&L endpoint is real, and **there is genuinely NO token-free app-API report endpoint for Sales & Traffic, Settlements, or Profit by SKU.** Combined with: (a) only 7 Reports-UI tabs (none of these), (b) React Query cache only ever loads the visited report, (c) P&L payload has no per-ASIN/per-settlement-line breakdown, (d) Orders is order-level, (e) Data scheme is schema-only — **no token-free LIVE surface exists for these three by any mechanism.** The only way to obtain their LIVE values is an **Export of the source table** (`amazon_sales_and_traffic_with_cogs` / `amazon_settlements_with_cogs` / `amazon_profit_by_sku_and_date`), which costs a token AND still yields no independent LIVE *report* to reconcile against (it just re-reads our own cache). Per rules → **NOT run; sections remain UNVERIFIED.**

**Internal chain re-confirmed fresh (cache = backend), July + August:**
| Section | July | August |
|---|---|---|
| S&T | not_synchronized (cache 07-20→31 only = leading gap; upstream S&T starts 07-20, proven by archived empty 07-01→19 export) — dashboard "not available" | £1,796.61 / 136u / 131o / 7,012 sess, partial→08-24 (missing 08-25→28) |
| Settlements | netRev £1,683.86 (referral −£691.15, fbaFulfil −£813.89, refunds −£48.67, promos −£305.69; 244 rows) | netRev £367.07 (referral −£347.19, fbaFulfil −£540.21, storage −£64.58, LT −£103.42, refunds −£89.85, promos −£108.20; 175 rows) |
| Profit-by-SKU | 42 ASINs, rev £3,815.41, profit £1,239.77, adSpend £1,015.58 | 48 ASINs, rev £2,001.84, profit £305.53, adSpend £1,028.29 |

Local sources (fresh Phase-1): S&T `60c14704…cov.json` `amazon_sales_and_traffic_with_cogs` (401ffcd7e5, SELLER_CENTRAL, 1067 rows, 72 ASINs, 36 cols, interval 07-20→08-24) → `getSellerSalesSummary`/`aggregateSalesRows`; Settlements `0c6ba485…cov.json` `amazon_settlements_with_cogs` (732dac689a, 1332 rows, 20 cols, interval 2025-08-19→08-28) → `getSellerFinancialsSummary`/`sumFeeBreakdown`; Profit-by-SKU `88e1cb18…cov.json` (dated canonical) `amazon_profit_by_sku_and_date` (57a0cb319c, 2393 rows, interval 2025-06-24→08-28) → `getSellerSkuProfitSummary`. Settlement duplicate-looking rows NOT removed (proven legitimate DataDoe rows, not pipeline dupes). Profit-by-SKU adSpend (£1,028.29 Aug) is the source's own per-SKU ad_spend, kept distinct from PPC-Campaigns SP (£1,044.23) — not substituted.

**Regression (fresh):** Jul PPC £1,015.58 · Aug PPC £1,044.23 · Jul P&L £1,009.85 · Aug P&L £1,104.89 — all unchanged; reconciliation 19/19, npm test 92/92. **DataDoe calls 0 · Sync 0 · Export 0 · Code changes 0. The three remain UNVERIFIED (no LIVE report / no token-free API — now positively proven, not merely "not found").**
