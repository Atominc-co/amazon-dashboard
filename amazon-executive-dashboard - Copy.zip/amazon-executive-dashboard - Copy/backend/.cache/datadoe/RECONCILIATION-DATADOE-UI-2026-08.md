# DataDoe UI reconciliation — AUGUST 2026

Evidence captured directly from the DataDoe Reports UI via Claude-in-Chrome.
Seller: **Vertex trading UK** (`19076074-9461-4eb0-a762-5f27185f9e5b`) · UK · **GBP**
Period: **2026-08-01 → 2026-08-28** · Comparison (UI auto): Jul 4 – Jul 31 · Interval: Month (single Total column).
Retrieved: 2026-08-29 (UI is LIVE as of this date). DataDoe export tokens spent this pass: **0**.

## A. Profit & Loss report (UI Total column)
| Metric | Aug 1–28 value | Comparison (Jul4–31) |
|---|---|---|
| Sales | £2,001.84 | £3,215.99 |
| Units | 150 | 203 |
| Refunds | 4 | 4 |
| Promo | £0.00 | £0.00 |
| Advertising cost | −£1,270.02 | −£1,150.27 |
| FBA shipping chargeback | −£29.37 | −£95.02 |
| Giftwrap | £0.00 | £0.00 |
| Refund cost | −£78.71 | −£26.11 |
| Amazon fees | +£361.62 | −£1,204.00 |
| Lost/damaged by Amazon | +£3.05 | £2.00 |
| Gross profit | £988.41 | £742.59 |
| **Net profit** | **£988.41** | £742.59 |
| Estimated payout | £985.36 | £740.59 |
| TACOS | 63.44% | 35.77% |
| % Refunds | 2.67% | 1.97% |
| **Margin** | **49.38%** | 23.09% |
| ROI | 32,406.89% | 37,129.50% |
| **Sessions** | **7,012** | 1,816 |

## B. Reconciliation vs our dashboard (Aug 1–28) + root causes
| Dashboard KPI | Our value (cache) | DataDoe (correct report) | Diff | Root cause / status |
|---|---|---|---|---|
| Gross Sales (S&T) | £1,796.61 | P&L Sales £2,001.84 (shipped basis) | — | Different basis (S&T ordered vs P&L shipped) + **staleness** (our cache = 08-28 snapshot, S&T to 08-24; UI live 08-29). PARTIAL, honest amber banner. |
| Sessions | 7,012 (S&T Aug 1–24) | P&L Sessions 7,012 | £0 | **PASS** — matches exactly (S&T Aug coverage 08-01..08-24). |
| PPC spend | £982.18 (ex-VAT, to 08-26) | P&L Advertising cost £1,270.02 (inc-VAT, full) | — | **20% VAT + staleness** (our Ad-Perf cache to 08-26; live to 08-28). Ratio 1.29 = 1.20 VAT × ~1.08 missing tail. |
| Net Profit | £676.39 (Profit by Date) | P&L Net profit £988.41 | — | Different basis (inc-VAT ad + fees) **+ staleness** (Profit-by-Date cache to 08-28 vs live). |
| Net Margin | 37.9% | P&L Margin 49.38% | — | Same basis+staleness reasons. |
| Net Revenue | £344.30 (Settlements to 08-27) | (no direct P&L line) | — | Settlement/cash basis, partial to 08-27. |

## C. Key point for August: STALENESS is the dominant cause
July (fully settled) reconciled to the penny on each KPI's correct source. August differs mainly because our
local cache is the **2026-08-28 snapshot** while the DataDoe UI is **live (2026-08-29)** — the recent mutable
days (08-25..08-28) accreted more data after our last sync (e.g. P&L Sessions Aug UI 7,012 == our S&T Aug 1-24
coverage, proving our S&T stops at 08-24). This is NOT a code error; a normal **Sync of the recent window**
closes it. The dashboard already flags this honestly (amber "partial local coverage … cached through <date>").
The VAT (PPC) and ordered/shipped/settled (sales/profit) definitional differences are the same as July and are
documented, not force-matched.

## Verdict August: no code error. Divergences = recent-window staleness + the same VAT/basis definitions as July.
Actionable (optional, data only): Sync the recent mutable window to refresh 08-25..08-28.

---

## RESOLUTION (2026-08-29) — recent-window staleness FIXED via authorized minimal sync
Proof it was staleness (not a definition gap): live DataDoe P&L Aug **1–24 Sales = £1,770.86** == our cache
08-01..08-24 (£1,770.86) to the penny. The whole £216.99 gap was the recent days (08-25..08-28), where our
cache held incomplete-day zeros (08-26/27/28 = £0) from the 2026-08-28 08:35 fetch.

Fetched ONLY 2026-08-24 → 2026-08-28 for the 5 dated sources (5 exports; no history re-download); merged
in place (replace-by-interval, 0 duplicates); raw archived. Results (backend, cache-only, after restart):
- **Profit-by-Date total_sales £1,784.85 → £2,001.84 == live P&L Sales £2,001.84 EXACT** ✓
- **Ad (all types, ex-VAT) £997.89 → £1,058.35; × 1.20 = £1,270.02 == live P&L Advertising cost EXACT** ✓
  (dashboard PPC = SP-only ex-VAT £1,028.40, labelled)
- Net Revenue (Settlements) £344.30 → £367.07 · Net Profit (Profit-by-Date) £676.39 → £832.92
- **Sales & Traffic**: the sync returned rows only for 08-24 (0 rows for 08-25..28) → DataDoe's S&T report
  genuinely LAGS to 08-24 (matches live P&L Sessions 7,012). Honest partial preserved; Gross Sales £1,797.

Dashboard (Aug 1-28, after backend restart PID 14464): Gross Sales £1,797 (S&T partial) · Net Revenue £367 ·
PPC £1,028 · **Net Profit £833** · Margin 41.6% · console clean · banner names ONLY S&T as partial.

REMAINING (legitimate, labelled): Net Profit (Profit-by-Date £833) ≠ P&L Net profit £988.41 — different
DataDoe reports; the sign flips vs July (July ours higher, Aug P&L higher) → genuinely different calcs, not
a fixable offset. Labelled on the card ("Profit by Date · ex-VAT ad (≠ P&L Net profit)"). Gross Sales (S&T,
ordered) ≠ P&L Sales (shipped £2,001.84); our shipped analog (Profit-by-Date) DOES equal £2,001.84.

---

## ADDENDUM — PPC-Campaigns row/campaign-level drift investigation (2026-08-29, re-verified LIVE)

**Fresh LIVE read (React Query cache, `reports/ads/campaigns/details`, interval MONTH *and* DAY — identical):**
- SPONSORED_PRODUCTS total: spend **£1,044.75** · sales **£1,267.35** · clicks **2,441** · impressions **707,881** · orders **97** · ACOS **82.44%** · CPC **£0.43**.
- All sponsored types: spend **£1,074.70** · × 1.20 = **£1,289.64** = LIVE P&L Advertising cost (internal cross-anchor holds).

**Local Ad-Performance cache (`e3ada2b9….cov.json`, fetchedAt 2026-08-29T15:23Z, interval 06-25..08-28), SP Aug 1–28:**
- spend **£1,028.40** · sales **£1,243.87** · clicks **2,394** · impressions **698,233** · orders **95**.

**Exact gap:** spend +£16.35 · sales +£23.48 · clicks +47 · impressions +9,648 · orders +2 (LIVE − local).

**Campaign-level diff (matched by campaign-name hash, 50 SP campaigns each side):**
- 50/50 campaigns present on BOTH sides — **no missing, extra, or duplicate campaigns**; **no SP-filter, field-mapping, currency, or VAT error** (both totals ex-VAT).
- The gap is distributed across **14 campaigns**, and **every single one is LIVE ≥ local** on spend/clicks/impressions/sales (never local > LIVE). Largest: one campaign +£4.50 spend / +£14.99 sales / +22 clicks; remainder are ≤£2.61 each, tapering to pennies.
- The per-campaign deltas sum **exactly** to the observed total gap.

**Proven root cause — expected sync-drift (advertising-data maturation), NOT a code/logic defect:**
Amazon restates advertising spend/clicks/impressions and 14-day-attributed sales upward for ~2–4 weeks after the activity date. Our local Ad-Performance snapshot was captured earlier and is behind DataDoe's current figures; DataDoe re-queries live each view. Corroboration: this file's own P&L Advertising anchor was **−£1,270.02** when captured earlier today; the freshly re-archived P&L (`raw/pnl-details-MONTH…json`) now shows **−£1,289.64** — DataDoe's *own* two reports both moved by the same +£16.35 (all-types), proving the movement is upstream, not ours. The backend aggregation is correct: July PPC reconciles to LIVE to the penny (£1,015.58) and all 17 offline reconciliation assertions pass.

**Can local evidence reproduce LIVE? NO.** The restated per-campaign/per-date values exist only at DataDoe. The P&L archive gives only the all-types range total (incl-VAT), not the per-date SP rows the cache stores.

**Minimum operation to close the gap (NOT executed — token rule):** one Ad-Performance export — source `Ad Performance by Campaign & Date` (`amazon_ads_performance_by_campaign_by_date`), range **2026-08-01 → 2026-08-28**, seller Vertex. ≈ 1 export request (single range, within the 2 req/s limit) ≈ 1 token/credit. Per instruction, STOPPED before executing; awaiting authorization. No code change is warranted — the dashboard is sync-only and correctly shows the last-synced snapshot.

---

## FIX APPLIED — targeted Ad-Performance refresh (2026-08-30, authorized, 1 export token)

**Action:** one targeted export of `Ad Performance by Campaign & Date` (sourceId `08cdc77d3d`), range **2026-08-01..2026-08-28**, via the PRODUCTION export primitives (createExport → poll → fetchExportRawData → archiveRawExport → mergeRowsForInterval → writeCoverage). NO aggregation/calculation logic changed. No broad Sync. No unrelated datasets touched.

**Raw archive (permanent, integrity-verified):**
`raw/a43f6944-b009-4300-94ba-9de6fda2b53b__e3ada2b94e6b8be267ca339e0b3a95defd744ebc.json`
- exportId `a43f6944-b009-4300-94ba-9de6fda2b53b` · requestId `0a9577d0-0885-45d1-8b02-559c799cadaa`
- requestedFrom 2026-08-01 · requestedTo 2026-08-28 · status COMPLETED · rowCount **1076** · byteLength 652503
- sha256 `ca0e0d5f91a608e952ae540e2393bb15df44139d2c57754071ae1cd8376eeedb` (recomputed = recorded ✓)
- retrievedAt 2026-08-29T18:31:48Z (server local-time skew; wall clock 2026-08-30)

**Full-chain verification (Aug 1–28 SPONSORED_PRODUCTS):**
| Stage | spend | sales | clicks | impressions | orders | ACOS | CPC |
|---|---|---|---|---|---|---|---|
| DataDoe LIVE | £1,044.75 | £1,267.35 | 2,441 | 707,881 | 97 | 82.44% | £0.43 |
| Raw archive | £1,044.75 | — | — | — | — | — | — |
| Local cache (.cov.json) | £1,044.75 | £1,267.35 | 2,441 | 707,881 | 97 | — | — |
| Backend (range=Custom & range=30d) | £1,044.75 | £1,267.35 | 2,441 | 707,881 | 97 | 82.44% | £0.43 |
| Dashboard (30d, covered=[08-01..08-28]) | **£1,045** (money = round £1,044.75) | — | — | — | — | — | — |

Derived (from backend totals) match LIVE: CTR 2,441/707,881 = 0.34%; CVR 97/2,441 = 3.97%; ROAS 1,267.35/1,044.75 = 1.21. Cross-anchor: cache all-types ex-VAT × 1.20 = £1,289.64 = LIVE P&L Advertising ✓.

**Backend restart:** old PID 9828 stopped; fresh `node dist/server.js` PID 8296 on :4000 (loads refreshed cache). **Regression:** July PPC £1,015.58 unchanged ✓; July P&L £1,009.85/26.47% ✓; Aug P&L £968.80/48.40% ✓; offline reconciliation test **19/19 pass** (two new assertions pin LIVE SP £1,044.75/£1,267.35).

**RESULT: PASS — LIVE = raw = cache = backend = dashboard for August PPC-Campaigns.**

---

## Independent FRESH re-verification — 2026-08-30 (this session, ZERO tokens spent)

Re-ran the entire chain from scratch to confirm the fix persisted and matches LIVE **right now**, using fresh Claude-in-Chrome evidence (NOT the prior audit as proof). No export/sync/token: only local disk reads + the session-cookie DataDoe Reports UI (React Query grid) + the running backend + the localhost dashboard.

**Disk state confirmed:** Ad-Performance cache `e3ada2b9….cov.json` mtime 2026-08-30T00:01, interval 2026-06-25..08-28, lastExportId `a43f6944…`, 2158 rows. Raw archive `a43f6944…` present, sha256 `ca0e0d5f…`, rowCount 1076. Only this one cov file carries the 00:01 mtime; every other source cache = 20:53 and the P&L archive = 22:00 → **PPC refresh is isolated; P&L/S&T/Settlements/Profit-by-SKU untouched.**

**Backend live:** PID 8272 on :4000 (already restarted since the fix; no restart needed this session). `/ppc-summary?range=Custom&from=2026-08-01&to=2026-08-28` returns adSpend 1044.75 / adSales 1267.35 / clicks 2441 / impressions 707881 / orders 97 / ACOS 82.44% / CPC 0.4280 / CVR 3.97%.

**Full-chain (Aug 1–28 SP), independently recomputed this session:**
| Stage | spend | sales | clicks | impr | orders | ACOS | CPC | CTR | CVR | ROAS |
|---|---|---|---|---|---|---|---|---|---|---|
| Raw archive (recomputed) | £1,044.75 | £1,267.35 | 2,441 | 707,881 | 97 | 82.44% | £0.43 | 0.345% | 3.97% | 1.21 |
| Local cache (recomputed) | £1,044.75 | £1,267.35 | 2,441 | 707,881 | 97 | 82.44% | £0.43 | 0.345% | 3.97% | 1.21 |
| Backend API | £1,044.75 | £1,267.35 | 2,441 | 707,881 | 97 | 82.44% | £0.43 | — | 3.97% | — |
| Dashboard (Custom 08-01→08-28) | £1,045 | £1,267 | — | (not displayed) | — | 82.4% | £0.43 | — | 4.0% | — |
| **DataDoe LIVE (re-read now)** | **£1,044.23** | **£1,267.35** | **2,440** | **707,091** | **97** | 82.39% | £0.43 | — | 3.98% | 1.21 |

**Campaign-level reconciliation (cache vs LIVE-now, matched by name):** 50 SP campaigns both sides; **0 missing, 0 extra.** Diffs (cache − live): spend +£0.52 (1 campaign, 2dp display-rounding of live per-campaign spend), clicks +1 (1 campaign), **impressions +790 spread across 24 campaigns (all cache≥live, largest +160 on "UY | SP | Facial Hair Removal | Auto"), sales £0.00 (exact, all 50), orders 0 (exact, all 50).**

**Interpretation:** cache/raw/backend/dashboard reproduce the LIVE **export-capture** values (18:31Z 2026-08-29) to the penny/unit. Since capture, LIVE has been restated ~0.1% — **impressions only**, one-directional (downward), spread across 24 campaigns = ordinary Amazon impression de-duplication. Spend/sales/orders/clicks (the ACOS/ROAS drivers) are unchanged. This residual is upstream data movement, **not** a source/date/attribution/aggregation/backend/frontend defect, and impressions are not even a displayed dashboard metric. Not chasing it with another export per rule #24 (a fresh snapshot would itself drift within hours; sales/spend already match exactly).

**Regression (all re-queried this session, all PASS/unchanged):** July PPC £1,015.58/£1,848.26/2,374/624,183/111/ACOS 54.95% ✓; July P&L £1,009.85 / £3,815.41 / 26.47% ✓; Aug P&L £968.80 / £2,001.84 / 48.40% ✓ (fully covered); Aug S&T £1,796.61/136u/131o/7,012 sess (honest partial through 08-24) ✓; Aug Settlements netRev £367.07 ✓; Aug Profit-by-SKU 48 SKUs £2,001.84 rev/£305.53 profit ✓. No fabricated zeros — unavailable dates render "—"/"Not available". P&L advertising basis intact: PPC ex-VAT £1,044.75 (SP) vs P&L incl-VAT (14-day attribution) — different bases, correct.

**S&T / Settlements / Profit-by-SKU:** no matching LIVE Reports-UI tab → not directly LIVE-verifiable (UNVERIFIED against a LIVE report, per rule); backend values recorded above from cache.

**Tokens/exports/syncs this session: 0.** No code changes. **VERDICT: PASS** — localhost matches LIVE DataDoe for August PPC-Campaigns on every displayed metric; the only non-displayed residual is a ~0.1% upstream impression restatement.

---

## Third fresh loop — 2026-08-30 (re-asked to "execute the final fix"; 0 tokens, 0 export, 0 sync, 0 code)

Re-ran the whole LIVE→raw→cache→backend→dashboard loop AGAIN from scratch (not reusing values above).

- **Premise check:** prompt claimed "Local/backend currently shows Spend £1,028.40". **FALSE now** — the live backend (:4000, PID 8272) returns **£1,044.75 / £1,267.35 / 2,441 / 707,881 / 97 / ACOS 82.44% / CPC £0.43** from `amazon_ads_performance_by_campaign_by_date`. The Aug PPC data is NOT stale; it was refreshed at 00:01 today (export a43f6944). No stale-cache fix remains to execute from local data.
- **LIVE re-read (Chrome grid, token-free):** £1,044.23 / £1,267.35 / 2,440 / 707,091 / 97 / ACOS 82.39% / CPC £0.428 / CTR 0.345% / CVR 3.98% / ROAS 1.21 (50 SP campaigns). Identical to the read ~30 min earlier → live is stable.
- **Chain:** raw = cache = backend = dashboard EXACTLY. vs LIVE-now: **sales, orders, CPC, ROAS exact; ACOS/CVR match at display precision; spend +£0.52, clicks +1, impressions +790 (all cache≥live).**
- **Can current-LIVE be reconstructed from local data? NO.** Local raw (18:31Z 2026-08-29 snapshot) physically holds impr 707,881 / clicks 2,441 / spend £1,044.75; current-LIVE is 707,091 / 2,440 / £1,044.23. The delta is upstream Amazon restatement (impression de-dup) that occurred AFTER capture — not a parse/filter/date/aggregation bug (per-campaign matched to the penny on sales/orders/clicks; only impressions drift, one-directional, spread over 24/50 campaigns). No local transform can turn 707,881 into 707,091 without discarding real rows (forbidden).
- **To match current-LIVE to the exact figure requires a NEW targeted Export** of `Ad Performance by Campaign & Date` (sourceId 08cdc77d3d), Aug 1–28, ~1 token. **No token-free alternative** (Reports-UI grid is read-only display with 2dp per-campaign spend and no daily rows → cannot faithfully rebuild the cache; writing grid values into cache = manual edit/hardcode, forbidden). Per rule 13 → **STOPPED BEFORE THE EXPORT. Not executed.**
- **Displayed dashboard PPC metrics vs LIVE-now:** Ad sales £1,267≈£1,267.35 ✓; ACOS 82.4%≈82.39% ✓; CPC £0.43=£0.43 ✓; Conversion 4.0%≈3.98% ✓; **Ad spend £1,045 (£1,044.75) vs live £1,044.23 = £0.52 / £1-at-whole-pound — the one displayed metric not exactly matching current-live.** Impressions/clicks/CTR/ROAS are not displayed on the dashboard.
- **Regression (fresh):** July PPC £1,015.58/£1,848.26/2,374/624,183/111 ✓; Jul P&L £1,009.85/£3,815.41/26.47% ✓; Aug P&L £968.80/£2,001.84/48.40% ✓; Aug S&T £1,796.61/136/131/7,012 (partial→08-24) ✓; Settlements £367.07 ✓; Profit-by-SKU 48/£2,001.84/£305.53 ✓. S&T/Settlements/SKU = UNVERIFIED (no LIVE report).
- **Outcome:** the original stale-£1,028 defect is fixed & verified. The remaining ~0.1% is upstream restatement, closeable only by a fresh Export I am forbidden to run without authorization. Not claiming a blanket PASS against *current* LIVE spend/impressions.

---

## Fourth loop — AUTHORIZED targeted Export executed; localhost now matches CURRENT LIVE exactly — 2026-08-30

User explicitly authorized "the minimum targeted Export rather than asking me again". Executed ONE targeted export (0 broad Sync, 0 other datasets, 0 hardcoding, 0 manual edits).

**Export (the single token-spending call):** `createExport` for source `Ad Performance by Campaign & Date` (sourceId `08cdc77d3d` / `amazon_ads_performance_by_campaign_by_date`), columns = exact PPC_COLUMNS, range **2026-08-01→08-28**, via `backend/scripts/refresh-ppc-aug.js` using PRODUCTION primitives (getExportSources → createExport → poll getExportStatus → fetchExportRawData → archiveRawExport → mergeRowsForInterval → coalesceIntervals → writeCoverage). NO aggregation-logic change.

- **New immutable raw archive (prior a43f6944 NOT overwritten):** `raw/3f108976-449b-4fd2-9f63-230565ea87a3__e3ada2b94e6b8be267ca339e0b3a95defd744ebc.json` — exportId `3f108976-449b-4fd2-9f63-230565ea87a3`, requestId `5e71ad52-6bf8-4f0c-911f-58d549135777`, rowCount 1077, byteLength 653115, **sha256 `aa50e467538bb09c33f4beb18065a2deaff4ca24362eb3219f172221df51867e`** (recomputed = recorded ✓), retrievedAt 2026-08-30T18:06:10Z.
- **Cache merge:** same datasetKey `e3ada2b9…`; replace-by-interval dropped old 08-01..08-28, kept 06-25..07-31, appended fresh → rows 2158→2159, intervals unchanged [06-25..08-28], fetchedAt 2026-08-30T18:06:10Z, lastExportId 3f108976. **0 duplicates.**
- **Backend restart:** killed PID 8272 → fresh `node dist/server.js` PID **5276** on :4000 (loads new coverage from disk).

**PRE→POST cache (Aug 1–28 SP):** spend £1,044.75→**£1,044.23** · clicks 2,441→**2,440** · impr 707,881→**707,091** · sales £1,267.35 (same) · orders 97 (same).

**Post-fix full-chain (Aug 1–28 SP) — LIVE re-read from scratch AFTER the fix:**
| Stage | spend | sales | clicks | impr | orders | ACOS | CPC | CTR | CVR | ROAS |
|---|---|---|---|---|---|---|---|---|---|---|
| DataDoe LIVE (post-fix re-read) | £1,044.23 | £1,267.35 | 2,440 | 707,091 | 97 | 82.39% | £0.428 | 0.3451% | 3.98% | 1.2137 |
| Raw archive (3f108976) | £1,044.23 | £1,267.35 | 2,440 | 707,091 | 97 | 82.39% | £0.428 | 0.3451% | 3.98% | 1.2137 |
| Local cache (e3ada2b9) | £1,044.23 | £1,267.35 | 2,440 | 707,091 | 97 | 82.39% | £0.428 | 0.3451% | 3.98% | 1.2137 |
| Backend API | £1,044.23 | £1,267.35 | 2,440 | 707,091 | 97 | 82.39% | £0.428 | — | 3.98% | — |
| Dashboard (Custom 08-01→28) | £1,044 | £1,267 | n/d | n/d | (conv) | 82.4% | £0.43 | n/d | 4.0% | n/d |

**ALL exact: LIVE = raw = cache = backend; dashboard matches at DataDoe rounding (£1,044.23→£1,044, £1,267.35→£1,267, 82.4%, £0.43, 4.0%).** Campaign count 50/50, 0 missing, 0 extra.

**Regression (fresh, post-restart):** July PPC £1,015.58/£1,848.26/2,374/624,183/111 (ACOS 54.95%) — UNCHANGED (replace-by-interval only touched Aug) ✓; Jul P&L £1,009.85/£3,815.41/26.47% ✓; Aug P&L £968.80/£2,001.84/48.40% ✓; Aug S&T £1,796.61/136/131/7,012 (partial→08-24) ✓; Settlements £367.07 ✓; Profit-by-SKU 48/£2,001.84/£305.53 ✓. P&L archive + S&T/Settlements/SKU caches untouched.

**Evidence:** `evidence/2026-08-30_datadoe-live-ppc-aug1-28-POSTFIX.jpg`, `evidence/2026-08-30_dashboard-ppc-aug1-28-POSTFIX.jpg`. Script: `scripts/refresh-ppc-aug.js`.

**DataDoe calls: 1 export (+ 1 non-token sources lookup). Sync: 0. Broad refresh: 0.** Code changes: added `scripts/refresh-ppc-aug.js` (a one-off maintenance script; no src/ or aggregation change). **VERDICT: PASS — localhost now matches CURRENT LIVE DataDoe PPC-Campaigns exactly on every metric (displayed + underlying).**

---

## Fifth loop — re-asked to "start the fix"; PROVED already-matched, NO new export — 2026-08-30

Re-ran the prove-before-calling gate (rule 7). Hard-reloaded the LIVE Reports UI (forced fresh fetch, not the in-page React Query cache) → LIVE Aug 1-28 SP = **£1,044.23 / £1,267.35 / 2,440 / 707,091 / 97 / ACOS 82.39% / CPC £0.428 / CTR 0.3451% / CVR 3.98% / ROAS 1.2137** — unchanged since the 18:06Z export (LIVE stable). Current local: RAW (3f108976) = CACHE (e3ada2b9, lastExportId 3f108976) = BACKEND (PID 5276) = **£1,044.23 / £1,267.35 / 2,440 / 707,091 / 97** — **exact match to LIVE**. Dashboard (Custom 08-01→28) = £1,044 / £1,267 / 82.4% / £0.43 / 4.0%.
**Campaign-level reconciliation (cache vs fresh LIVE, by name): 50/50, 0 missing, 0 extra, 0 changed; total diff spend £0.00 / sales £0.00 / clicks 0 / impressions 0 / orders 0.** Every campaign matches every field.
Because local already reproduces LIVE exactly, an Export was NOT required → none run (rules 5/7/8). Regression re-checked fresh, all unchanged (July PPC £1,015.58 · Jul P&L £1,009.85 · Aug P&L £968.80 · S&T £1,796.61 partial→08-24 · Settlements £367.07 · SKU 48/£2,001.84/£305.53). **DataDoe calls this loop: 0. Export: 0. Sync: 0. Code changes: 0. VERDICT: PASS.**

---

## Sixth loop — 2026-08-31 (date rolled; re-verified fresh, NO export; stale test anchors updated)

Date advanced to 2026-08-31 → re-checked whether August PPC drifted overnight. Hard-reloaded LIVE PPC-Campaigns (forced fetch) = **£1,044.23 / £1,267.35 / 2,440 / 707,091 / 97 / ACOS 82.39% / CPC £0.428 / CTR 0.3451% / CVR 3.98% / ROAS 1.2137** — IDENTICAL to 08-30 (August fully matured, no overnight drift). Local RAW(3f108976)=CACHE(e3ada2b9)=BACKEND(PID 5276)= same, exact. Dashboard reloaded + Custom 08-01→28 re-applied (fresh backend fetch) = £1,044/£1,267/82.4%/£0.43/4.0%. **Campaign-level: 50/50, 0 missing, 0 extra, 0 changed, total diff £0/£0/0/0/0.** No export needed (rules 3/23) — none run.
**Test-fixture update (rule 20 — expected data only, NO production code):** `reconciliation-datadoe-ui.test.js` had two stale August anchors from the 1st export (a43f6944): SP spend £1,044.75 and P&L advertising £1,289.64. Fresh LIVE proves both legitimately changed (2nd export 3f108976 full-range re-fetch matured SB/SD up): SP spend now **£1,044.23** (LIVE PPC-Campaigns SP, verified via Chrome); all-types ex-VAT **£1,082.83** (SP £1,044.23 + SB £38.30 + SD £0.30) × 1.20 = **£1,299.40** = LIVE P&L advertising_cost (read from live P&L payload). Updated both anchors + comment to the verified values. Tests: **reconciliation 19/19, npm test 92/92** (build clean). Evidence: `evidence/2026-08-31_dashboard-ppc-aug1-28.jpg`.
**OBSERVATION (out of scope, P&L closed):** LIVE P&L net_profit has itself restated to £1,104.87 (MONTH) vs our static archive £968.80 — flagged, not changed. **DataDoe calls: 0. Export: 0. Sync: 0. Production code changes: 0 (test fixture only). VERDICT: PASS.**

---

## Seventh loop — 2026-08-31: P&L Net Profit refreshed (TOKEN-FREE app-API capture, no export/sync)

User escalated the P&L staleness to highest priority and authorized the fix. **P&L does NOT use the export/token API** — Net Profit comes from the DataDoe app-API `GET /api/core/reports/profit-and-loss/details` (session cookie, token-free), captured via Claude-in-Chrome and archived under `.cache/datadoe/pnl/`. So this refresh spent **0 tokens, 0 exports, 0 syncs**.

- **Fresh LIVE P&L captured (interval=DAY, from React Query state):** 59 per-date rows 07-01..08-28. **July net_profit £1,009.85 / sales £3,815.41 (unchanged — settled). August net_profit £1,104.89 / sales £2,147.68 (restated up from £968.80/£2,001.84).** The August rise is driven by reimbursements posted on 08-06 (+£208.82) and 08-07 (+£856.22). DAY-basis £1,104.89 ≈ MONTH-view £1,104.87 (£0.02 interval rounding).
- **Root cause:** the P&L archive `pnl-vertex-2026-07-01_2026-08-28.json` was a static 2026-08-29 22:00 snapshot; `datadoe.pnl.ts loadPnlDaily` folds all `pnl/*.json` by date with later-filename-wins, but no fresher file existed → the stale August net_profit (£968.80) flowed to the dashboard (£969).
- **Fix (pipeline, no hardcode, no override):** wrote a fresh archive `pnl/pnl-vertex-refresh-2026-08-31.json` (59 rows, sha256 `205d613ded01c136d4e046da65e1ecc46a65180d4b102fc7a82a9cdc99537ba3`, retrievedAt 2026-08-31). Filename sorts lexically AFTER the old file, so `loadPnlDaily` supersedes the stale August rows on date collision (July identical, so unchanged). **Old archive preserved** (not overwritten). `loadPnlDaily` reads disk fresh each request → **no backend restart needed**; verified backend picks it up immediately.
- **Full P&L chain (post-fix):**
  | Metric | LIVE (DAY) | LIVE (MONTH) | Local archive | Backend | Dashboard |
  |---|---|---|---|---|---|
  | Aug net_profit | £1,104.89 | £1,104.87 | £1,104.89 | £1,104.89 | £1,105 |
  | Aug margin | 51.45% | ~51.4% | 51.45% | 51.45% | 51.4% |
  | Aug P&L sales | £2,147.68 | £2,147.68 | £2,147.68 | £2,147.68 | (denominator) |
  | Jul net_profit | £1,009.85 | £1,009.85 | £1,009.85 | £1,009.85 | £1,010 |
  All match at DataDoe rounding. Dashboard 30d Net Profit also moved £983→£1,119 (picks up 08-06/07).
- **Test-fidelity fix (not a value change):** `reconciliation-datadoe-ui.test.js` read the pnl dir by CONCATENATING all files' rows — which double-counts dates present in >1 archive (after a refresh). Rewrote it to mirror production `loadPnlDaily` exactly (date→row map, later filename wins). July still £1,009.85 / 26.47% (deduped). **Tests: reconciliation 19/19, npm test 92/92, build clean.**
- **Regression:** July PPC £1,015.58 ✓ · Aug PPC £1,044.23 (unchanged — P&L fix isolated to pnl archive) ✓ · July P&L £1,009.85 ✓ · Aug P&L £1,104.89 (FIXED) ✓ · S&T £1,796.61 partial ✓ · Settlements £367.07 ✓ · Profit-by-SKU 48/£2,001.84/£305.53 ✓. No fabricated zeros.
- **Evidence:** `evidence/2026-08-31_dashboard-pnl-fixed-aug1-28.jpg`. **DataDoe export/sync/token: 0.** Code changes: test fixture only (no src/ change — the fix was a data-archive refresh through the existing pipeline). **VERDICT: PASS for P&L (July + August) and PPC (July + August).**

---

## Re-verification pass (2026-08-31, no changes) — August PPC still matches LIVE
Hard-reloaded LIVE PPC-Campaigns → £1,044.23/£1,267.35/2,440/707,091/97/ACOS 82.39%/CPC £0.428/CTR 0.3451%/CVR 3.98%/ROAS 1.2137. Raw 3f108976 = cache (e3ada2b9, lastExportId 3f108976, fetchedAt 2026-08-30T18:06Z) = backend = LIVE; **required values already local → no fetch (rules 2/3)**. Campaign-level 50/50, 0 missing/extra/changed, £0 total diff. Dashboard (Custom Aug 1-28): PPC £1,044 · Net Profit £1,105 · Net Margin 51.4% · Gross Sales £1,797 · Net Revenue £367. Regression: Jul PPC £1,015.58 · Jul P&L £1,009.85 · Aug P&L £1,104.89/51.45% · S&T £1,796.61 (partial→08-24) · Settlements £367.07 · SKU 48/£2,001.84/£305.53. Tests 19/19 + 92/92. **DataDoe/Sync/Export/code changes: 0. PPC & P&L PASS; S&T/Settlements/SKU UNVERIFIED (no LIVE report / no token-free API).**

---

## 2026-08-31 — FRESH LIVE↔local PPC/P&L investigation (0 exports, 0 sync; token-free React Query LIVE reads)

### August PPC-Campaigns (Sponsored Products, 2026-08-01→08-28)

Chain (raw → cache → backend → dashboard vs LIVE):
| metric | raw a43f6944 (08-29 18:31Z) | raw 3f108976 ACTIVE (08-30 18:06Z) | cov cache | backend ppc-summary | dashboard | LIVE (08-31 React Query) |
|---|---|---|---|---|---|---|
| SP spend | 1044.75 | **1044.23** | 1044.23 | 1044.2300 | £1,044 | **1044.75** |
| SP sales | 1267.35 | 1267.35 | 1267.35 | 1267.3500 | £1,267 | 1267.35 |
| clicks | 2441 | 2440 | 2440 | 2440 | (not shown) | 2441 |
| impressions | 707,881 | 707,091 | 707,091 | 707,091 | (not shown) | **706,802** |
| orders | 97 | 97 | 97 | 97 | (not shown) | 97 |
| ACOS | — | 82.3948 | 82.3948 | 82.3948 | 82.4% | 82.4358 |
| CPC | — | 0.4280 | 0.4280 | 0.4280 | £0.43 | 0.4280 |
| CVR | — | 3.9754 | 3.9754 | 3.9754 | 4.0% | 3.9738 |
| ROAS | — | 1.2137 | 1.2137 | 1.2137 | (not shown) | 1.2131 |

raw = cache = backend = dashboard EXACTLY (active export 3f108976). LIVE − local aggregate delta: **spend +£0.52, clicks +1, impr −289, sales £0, orders 0.**

Campaign-level diff (LIVE 50 SP ↔ local 50 SP): **1:1 name match — 0 missing, 0 extra, 0 duplicate.** 22 campaigns differ:
- Non-impression delta comes from EXACTLY ONE campaign: **"FO | SP | Thrilling Tango | Auto"** — LIVE spend £18.82 / clicks 39 vs local £18.30 / 38 (Δ +£0.52 / +1).
- Impressions −289 = de-dup declines across 21 campaigns (all LIVE ≤ local: −8,−33,−37,−30,… ).

Reconstruction test — is current LIVE present in local files?
- Thrilling Tango current-LIVE = spend £18.82 & clicks 39 (== older raw a43f6944) BUT impr 32,580 (== newer raw 3f108976, NOT a43's 32,602).
- LIVE total impressions 706,802 sit BELOW every stored snapshot (707,881 / 707,091). No single local file — nor any combination — equals current LIVE. It is a fresh upstream restatement.

Root-cause elimination (all ruled out by evidence): wrong date filter (both Aug 1–28 inclusive) ✗ · attribution handling (both 14-day/SALES-140) ✗ · stale/incorrect source-file selection (cache correctly uses NEWEST export) ✗ · incomplete aggregation (50/50 campaigns, sums exact) ✗ · field mapping (SP filter + fields correct) ✗ · duplicate/missing rows (none) ✗ · frontend/backend calc (raw=cache=backend=dashboard) ✗. **CONCLUSION: no local defect. The residual is genuine sub-0.1% Amazon ad restatement since the 08-30 18:06Z export capture.**

Displayed-metric impact: only SPEND crosses a whole-£ rounding boundary — dashboard £1,044 (1044.23) vs LIVE £1,045 (1044.75). Sales/ACOS/CPC/CVR all round identically. NO CODE CHANGE MADE. Data NOT locally reconstructable → per protocol, STOPPED before export. Minimum to match current LIVE: 1× Ad-Performance export (`amazon_ads_performance_by_campaign_by_date`, sourceId 08cdc77d3d, range 2026-08-01→08-28) ≈ 1 token — NOT executed (and a moving target: will drift again).

### July PPC-Campaigns (SP, 2026-07-01→07-31) — LIVE React Query
LIVE spend £1015.58 · sales £1848.26 · clicks 2374 · impr 624,183 · orders 111 · ACOS 54.9479 · CPC 0.4278 · CVR 4.6757 · ROAS 1.8199 · 42 SP campaigns.
== local cache == backend (1015.58/1848.26/2374/624183/111) == dashboard (£1,016/£1,848/54.9%/£0.43/4.7%) **EXACTLY.** July's 14-day attribution fully settled → no drift. **PASS.**

### P&L (interval=DAY) — LIVE React Query + UI screenshot
- JULY: LIVE net_profit £1009.85 · sales £3815.41 · margin 26.47% == backend premium (1009.85/3815.41/26.4677) == dashboard (£1,010/26.5%). **PASS.** (LIVE line items, dashboard-unrendered: advertising_cost −£1218.68 incl-VAT, amazon_fees −£1432.46, refund_cost −£41.45.)
- AUGUST: LIVE net_profit **£1137.16** · sales £2198.13 · margin 51.73% (advertising −£1300.01, amazon_fees +£344.07, refund_cost −£78.71, FBA chargeback −£29.37). Dashboard/backend archive = £1104.89 / £2147.68 / 51.45% → dashboard shows £1,105 / 51.4%. **MISMATCH −£32.27** = further upstream P&L restatement (reimbursements/ad-attribution) since the 08-31 token-free P&L archive capture. P&L refresh is TOKEN-FREE (app-API capture, no export) but is OUTSIDE this turn's PPC scope → flagged, NOT executed.

### Three UNVERIFIED-vs-LIVE sections (no corresponding LIVE Reports-UI report) — local trace only
- **Sales & Traffic**: source `amazon_sales_and_traffic_by_date` → cov cache `480bd1536af0…`/`97af0470…` → backend `getSellerSalesSummary` → frontend headline+trend-stats. Jul = not_synchronized (leading gap, upstream-empty pre-07-20). Aug = £1,796.61/136u/131o/7,012 sess (partial to 08-24). UNVERIFIED (LIVE UI has only P&L "sessions", not substitutable).
- **Settlements**: source `amazon_settlements_with_cogs` → cov `0c6ba485…` → backend `getSellerFinancialsSummary` → frontend "Where the money went". Jul netRev £1,683.86; Aug £367.07. UNVERIFIED (no LIVE Settlements report).
- **Profit by SKU**: source `amazon_profit_by_sku_and_date` → cov `88e1cb18…` → backend `getSellerSkuProfitSummary` → frontend product cards. Jul 42 ASINs; Aug 48 ASINs (rev £2,001.84/… ). UNVERIFIED (LIVE PPC-Products ≠ definition).

### Tallies: DataDoe export calls = 0 · Sync = 0 · Export = 0. LIVE reads = token-free React Query / ag-grid (no export triggered). Code changes = 0.

---

## 2026-08-31 (deep reconstruction proof) — can FRESH LIVE Aug be rebuilt from local? NO. (0 export, 0 sync, 0 code change)

FRESH LIVE re-read (React Query, dataUpdatedAt age <20s, reload-forced): SP spend £1044.75 · sales £1267.35 · clicks 2441 · impr 706,802 · orders 97 · ACOS 82.44 · CPC £0.4280 · CVR 3.9738 · ROAS 1.2131 (50 SP campaigns). Stable across 3 reads this session.

### PPC — ALL local files carrying `amazon_ads_performance_by_campaign_by_date`
| file | retrievedAt | Aug coverage | SP spend | sales | clicks | impr | orders | ==LIVE? |
|---|---|---|---|---|---|---|---|---|
| raw 9e855728 | 08-29 15:23Z | 08-24..28 only | 121.42 | 209.32 | 289 | 114,736 | 14 | no (partial) |
| raw a43f6944 | 08-29 18:31Z | 08-01..28 | **1044.75** | 1267.35 | **2441** | 707,881 | 97 | no (impr Δ−1079) |
| raw 3f108976 (ACTIVE) | 08-30 18:06Z | 08-01..28 | 1044.23 | 1267.35 | 2440 | 707,091 | 97 | no (Δ spend+.52/clk+1/impr−289) |
| cov cache = 3f108976 | — | 08-01..28 | 1044.23 | 1267.35 | 2440 | 707,091 | 97 | no |
(all other raw files are Settlements/Profit-by-SKU/Profit-by-Date/S&T — NOT ad data. Only one ad cov.json exists.)

Per-field reconstruction (is each LIVE campaign-field present in ANY snapshot?): **spend ✓, clicks ✓, sales ✓, orders ✓ — but IMPRESSIONS for 22 campaigns exist in NO local snapshot** (LIVE total 706,802 sits below every capture 707,091/707,881; Amazon de-dups impressions downward monotonically).
Single-snapshot full match: best (active 3f108976) = 24 field-level mismatches; a43f6944 = 28. **NONE = 0.**
Combining a43f6944 spend/clicks with 3f108976 impressions to fake LIVE = explicitly forbidden (manufacture). **PROVEN: current LIVE Aug PPC is NOT reconstructable from existing local data.**

Root cause (evidence, not assumption): **DataDoe/Amazon UPSTREAM RESTATEMENT.** Ruled out with data: date-definition (both Aug 1-28 inclusive), attribution window (both 14-day SALES-140; sales & orders identical LIVE↔local), stale-snapshot-as-bug (cache correctly holds newest export), wrong source file (only newest full export is valid), wrong field (snake→camel map exact), aggregation (50/50, sums exact), campaign filter (50 SP identities identical). The only movements are impression de-dup (−289 across 22 campaigns) + one campaign spend/click maturation (FO | SP | Thrilling Tango: £18.30/38→£18.82/39). Trace LIVE adSpend→raw ad_spend→cov.rows→getSellerPpcSummary totals.adSpend→/ppc-summary→frontend money(adSpend): mapping correct end-to-end; only upstream numbers changed.

Displayed impact: only SPEND crosses the whole-£ boundary — dashboard £1,044 (1044.23) vs LIVE £1,045 (1044.75). Sales/ACOS/CPC/CVR round identically. To match: 1× Ad-Performance export (source 08cdc77d3d, range 2026-08-01→28) ≈1 token — **NOT executed (awaiting authorization; moving target).**

### P&L — ALL local pnl archives
| file | Aug net_profit | Aug sales |
|---|---|---|
| pnl-vertex-2026-07-01_2026-08-28.json (08-29) | 968.80 | 2001.84 |
| pnl-vertex-refresh-2026-08-31.json (08-31 00:26, ACTIVE, later-name-wins) | **1104.89** | 2147.68 |
| **FRESH LIVE (now)** | **1137.16** | **2198.13** |

Current LIVE P&L (£1137.16 / £2198.13) is in NEITHER local archive → **NOT reconstructable locally** (fresh restatement: FBA reimbursements/credits — amazon_fees flipped to +£344.07 vs July −£1432.46 — and ad-attribution maturing since the 08-31 00:26 capture). LIVE components (interval=DAY): Sales £2198.13 · Advertising −£1300.01 · Amazon fees +£344.07 · Refund cost −£78.71 · FBA shipping chargeback −£29.37 · Lost/damaged folded into amazon_fees reimbursements · Net Profit £1137.16 · Margin 51.73%. Dashboard renders Net Profit £1,105 / Margin 51.4% (from active archive £1104.89); the P&L line items are NOT rendered (dashboard cost breakdown = ex-VAT Settlements). Refresh is TOKEN-FREE (app-API capture) but current LIVE is not in-archive → **NOT executed (awaiting authorization).**

### Tallies: DataDoe export = 0 · Sync = 0 · Export = 0 · code changes = 0 · data writes = 0. Tests unchanged (92/92 + 19/19). Both PPC & P&L Aug mismatches PROVEN = upstream restatement, not local defects, not locally reconstructable.

---

## 2026-08-31 — IMPLEMENTED: 6 DataDoe P&L components now displayed (0 export, 0 sync, 0 tokens)

Problem: dashboard rendered only Net Profit/Margin from the DataDoe P&L; the 6 line items were NOT displayed. Proven NOT in any local file (pnl archive stored only [date,net_profit,sales]; the Profit-by-Date export is a different report — forbidden to infer from). The components exist only in the app-API P&L (`/profit-and-loss/details`, session-cookie, token-free — the SAME source that already built the archive & powers Net Profit).

Field mapping (DataDoe P&L UI row → app-API field): Sales→`sales`, Advertising→`advertising_cost` (incl-VAT), Amazon fees→`amazon_fees`, Refund cost→`refund_cost`, FBA chargeback→`shipping_costs` (`fba_shipping_chargeback`), Lost/damaged by Amazon→`cost_of_goods` (`lost_damaged`). Identity per day & per range: Sales+Advertising+Amazon fees+Refund cost+FBA chargeback+Lost/damaged = Net profit (closes exactly).

Data: token-free capture of July+August per-date components into `pnl/pnl-vertex-refresh-2026-08-31b-components.json` (schemaVersion 2, columns `[date,net_profit,sales,advertising_cost,amazon_fees,refund_cost,fba_shipping_chargeback,lost_damaged]`, 59 rows, 0 identity failures). Old v1 archives preserved. July net_profit £1009.85 unchanged (settled); August is fresh LIVE £1136.71 (Amazon restated up from £1104.89 — capturing full components necessarily brings Aug to current LIVE).

Backend `datadoe.pnl.ts`: PnlDayRow/PnlRangeResult gain 5 component fields + `componentsAvailable`; loadPnlDaily reads them positionally (v1 rows → null, never 0); getPnlRange sums with an all-covered-days-present guard (any v1-only day → components null, honest "unavailable"). Controller `getSellerFinancialsSummaryPremium` adds a `components` object; profit/totalSales/marginPct untouched.

Frontend `index.html`: new additive card `#pnl-report` "DataDoe Profit & Loss" (6 rows + Net profit, each with source, "Not available" when unavailable). Existing Settlements "Where the money went" breakdown, PPC, Net Profit/Margin untouched.

Verified (localhost, fresh): July card Sales £3,815 / Advertising −£1,219 / Amazon fees −£1,432 / Refund cost −£41 / FBA chargeback −£115 / Lost/damaged £2 / Net profit £1,010. Aug card £2,198 / −£1,300 / £344 / −£79 / −£29 / £3 / £1,137. All == LIVE (rounded, whole £). Aug headline Net Profit £1,105→£1,137 (now matches LIVE), Margin 51.7%; PPC £1,044 unchanged.

Tests: `npm test` 92/92 + `reconciliation-datadoe-ui.test.js` 19/19 (July P&L £1009.85 guard) + new `pnl-components.test.js` 20/20 (both months exact + identity + July regression guard). Regression: PPC/S&T/Settlements/SKU backend values unchanged. DataDoe export=0, sync=0, tokens=0.
