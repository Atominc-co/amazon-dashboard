# COMPLETE JULY 2026 DASHBOARD RECONCILIATION — 2026-08-31

Fresh LIVE DataDoe evidence via Claude-in-Chrome (React Query + ag-grid + screenshots). Seller Vertex trading UK (19076074-9461-4eb0-a762-5f27185f9e5b), GBP. Date selector verified on localhost: **2026-07-01 → 2026-07-31** (basis "settlement basis"). Zero Export, zero Sync, zero code changes.

## Date verification
- Localhost selector: 2026-07-01 → 2026-07-31 inclusive (confirmed on screen).
- Backend queries: `range=Custom&from=2026-07-01&to=2026-07-31`; `getPnlRange`/coverage use inclusive [from,to] local-calendar days (verified in reconciliation-datadoe-ui.test.js "date filter is inclusive [07-01,07-31] excludes 06-30/08-01").
- LIVE DataDoe P&L + PPC grids both show period "Jul 1, 2026 - Jul 31, 2026". Same seller, marketplace UK.
- July is SETTLED (14-day ad attribution closed by end-Aug) → LIVE values immutable; every read this session agrees to the penny.

## LIVE DataDoe (fresh)
- **PPC-Campaigns report (SP, 42 campaigns):** spend 1015.58 · sales 1848.26 · clicks 2374 · impr 624,183 · orders 111 · ACOS 54.9479 · CPC 0.4278 · CTR 0.3803 · CVR 4.6757 · ROAS 1.8199.
- **Profit & Loss report:** Sales 3815.41 · Advertising(Sponsored Products) −1218.68 (grid MONTH-total shows −1218.70, a £0.02 DataDoe-internal DAY-sum vs MONTH-total rounding) · Amazon fees −1432.46 · Refund cost −41.45 · FBA shipping chargeback −114.97 · Lost/damaged by Amazon +2.00 · Net profit 1009.85 · Margin 26.47% · Units 231 · Sessions 1816.

## Metric-by-metric (Dashboard label | rendered | backend | LIVE | source | date | display | verdict)

### DIRECTLY VERIFIABLE — PASS (rounded, underlying matches exactly)
| Dashboard | Rendered | Backend | LIVE | Source/report | Rounding | Verdict |
|---|---|---|---|---|---|---|
| Headline PPC Spend / PPC card Ad spend | £1,016 | 1015.58 | 1015.58 | PPC-Campaigns · ad_spend (ex-VAT) | Math.round £ | PASS (underlying matches, display rounded) |
| PPC card Ad sales | £1,848 | 1848.26 | 1848.26 | PPC-Campaigns · ad_sales (14-day) | £ | PASS |
| PPC card ACOS | 54.9% | 54.9479 | 54.9479 | PPC-Campaigns (spend/sales) | 1dp | PASS |
| PPC card CPC | £0.43 | 0.4278 | 0.4278 | PPC-Campaigns (spend/clicks) | 2dp | PASS |
| PPC card Conversion (CVR) | 4.7% | 4.6757 | 4.6757 | PPC-Campaigns (orders/clicks) | 1dp | PASS |
| Campaigns burning margin (3 rows) | £36/£7/518.0%; £70/£22/320.2%; £40/£21/192.5% | matches | PPC-Campaigns per-campaign | £/1dp | PASS (part of the SP dataset whose aggregate matches LIVE to the penny) |
| P&L card Sales | £3,815 | 3815.41 | 3815.41 | P&L · sales | £ | PASS |
| P&L card Advertising | −£1,219 | −1218.68 | −1218.68/−1218.70 | P&L · advertising_cost (incl-VAT) | £ | PASS (both →£1,219) |
| P&L card Amazon fees | −£1,432 | −1432.46 | −1432.46 | P&L · amazon_fees | £ | PASS |
| P&L card Refund cost | −£41 | −41.45 | −41.45 | P&L · refund_cost | £ | PASS |
| P&L card FBA chargeback | −£115 | −114.97 | −114.97 | P&L · fba_shipping_chargeback | £ | PASS |
| P&L card Lost/damaged | £2 | 2.00 | 2.00 | P&L · lost_damaged (cost_of_goods) | £ | PASS |
| P&L card / headline Net Profit | £1,010 | 1009.85 | 1009.85 | P&L · net_profit | £ | PASS |
| Headline Net Margin | 26.5% | 26.4677 | 26.47 | P&L (net_profit÷sales) | 1dp | PASS |
| Cost-breakdown "PPC ad spend" | −£1,016 | 1015.58 | 1015.58 | Ad Performance · ad_spend | £ | PASS |
| Cost-breakdown "Net profit" | £1,010 | 1009.85 | 1009.85 | P&L · net_profit | £ | PASS |

### UNVERIFIED — no LIVE Reports-UI report (never PASS)
| Dashboard | Rendered | Backend | Source (localhost) | Local cache file | LIVE report? | Verdict |
|---|---|---|---|---|---|---|
| Headline Net Revenue | £1,684 | 1683.86 | Settlements · total | 0c6ba485…cov.json | none | UNVERIFIED |
| Cost-breakdown Refunds & returns | −£49 | −48.67 | Settlements · refunded_amount | 0c6ba485… | none | UNVERIFIED |
| Cost-breakdown Promotions & coupons | −£306 | −305.69 | Settlements · promotion/coupon | 0c6ba485… | none | UNVERIFIED |
| Cost-breakdown Amazon referral fee | −£691 | −691.15 | Settlements · referral_fee | 0c6ba485… | none | UNVERIFIED |
| Cost-breakdown FBA fulfilment fee | −£814 | −813.89 | Settlements · fba_per_unit_fulfillment_fee | 0c6ba485… | none | UNVERIFIED |
| Cost-breakdown FBA storage | −£0 | 0 | Settlements · fba_storage_fee | 0c6ba485… | none | UNVERIFIED |
| Cost-breakdown Aged/long-term storage | −£0 | 0 | Settlements · long_term_storage_fee | 0c6ba485… | none | UNVERIFIED |
| Cost-breakdown Other Amazon fees | −£0 | 0 | Settlements · amazon_fees | 0c6ba485… | none | UNVERIFIED |
| Cost-breakdown Return processing | −£0 | — | Settlements · fba_customer_return… | 0c6ba485… | none | UNVERIFIED |
| Products (45 SKU cards: revenue/margin/adSpend/ACOS) | per-SKU | sku-profit-summary (42 ASINs/814 rows) | Profit by SKU · … | 88e1cb18…cov.json | none | UNVERIFIED |

### NOT DATE-DRIVEN (snapshot; do not change with July selector) — UNVERIFIED for July
| Dashboard | Rendered | Source | Note |
|---|---|---|---|
| Inventory: Units on hand 2,517 / Days cover 304d / 58 ASINs / Inbound 0 | snapshot "as of 2026-08-26" | FBA Inventory (exact-key snapshot) | current snapshot, NOT July data |
| Product listings: Active 13 / Buy Box — / Suppressed — / Stranded — | snapshot | Listings | current snapshot, NOT July data |

### ABSENCE (honest "Not available") — different dataset than P&L; UNVERIFIED
| Dashboard | Rendered | Source | Note |
|---|---|---|---|
| Headline Gross Sales | — Not available | Sales & Traffic · total_sales | S&T not_synchronized (missing 07-01..07-19, upstream-empty pre-07-20). DIFFERENT dataset from P&L "Sales" £3,815.41 (ordered-sales S&T basis vs P&L shipped basis). No LIVE S&T report. |
| Headline Units Sold | — Not available | S&T · total_units | DataDoe P&L Units=231 exists but dashboard sources Units from S&T (empty); 231 not displayed. |
| Trend stats: AOV / Units-day / Sessions / Unit-session% | all — | S&T-derived | DataDoe P&L Sessions=1816 exists but dashboard Sessions is S&T-sourced (empty); 1816 not displayed. |
| PPC card TACOS | — Not available | PPC spend ÷ S&T gross sales | needs Gross Sales (S&T, empty) → honest N/A. |

## Findings
- **No dashboard value is WRONG.** Every directly-verifiable value matches LIVE exactly (display rounded to whole £ / 1dp; underlying identical). P&L identity closes: 3815.41−1218.68−1432.46−41.45−114.97+2.00 = 1009.85.
- **Dataset-source distinction (by design, flagged):** headline Gross Sales/Units/Sessions come from **Sales & Traffic** (empty for July pre-07-20 → "Not available"), NOT from the DataDoe **P&L** report (which has Sales 3815.41 / Units 231 / Sessions 1816). The P&L "Sales" £3,815 IS shown in the new P&L card; the S&T-based headline "Gross Sales" is a different metric/basis and is honestly unavailable. This is a source difference, not a defect.
- **DataDoe-internal rounding:** P&L grid MONTH-total Sponsored Products −1218.70 vs per-day sum −1218.68 (£0.02). Dashboard uses per-day sum; both display £1,219.
- Settlements, Profit-by-SKU: no LIVE Reports-UI report → UNVERIFIED. Inventory/Listings: current snapshots, not July-date-driven → UNVERIFIED for July.

## Tallies
DataDoe LIVE reads: token-free React Query/grid (no export triggered). Export=0 · Sync=0 · Code changes=0.
Evidence screenshots: LIVE P&L grid, LIVE PPC-Campaigns grid, localhost July headline + P&L card.

## FINAL JULY STATUS
Directly-verifiable sections (PPC-Campaigns + P&L, incl. the 6 new components, Net Profit, Net Margin): **PASS** (all match LIVE, rounded). But because Net Revenue / Settlements cost-lines / Profit-by-SKU / Inventory / Listings / Gross-Sales-Units-Sessions are **UNVERIFIED** (no LIVE report or snapshot), the overall dashboard status is **NOT PASS** — it is **PASS-where-verifiable / UNVERIFIED-elsewhere**.
