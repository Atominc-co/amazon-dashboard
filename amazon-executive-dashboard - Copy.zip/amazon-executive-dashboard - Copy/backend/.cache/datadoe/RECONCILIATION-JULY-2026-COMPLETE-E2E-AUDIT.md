# COMPLETE END-TO-END JULY 2026 DASHBOARD AUDIT — 2026-08-31 (read-only)

Fresh LIVE DataDoe evidence via Claude-in-Chrome this session. Seller Vertex trading UK (19076074-9461-4eb0-a762-5f27185f9e5b), GBP. **Zero Export, zero Sync, zero code changes.**

## 1. Date range verification
Selector confirmed on screen: **2026-07-01 → 2026-07-31**. Fresh page load (default 30d: £1,755/£1,150) changed fully to July values (£1,684/£1,010/"Not available") after selecting Custom → no stale 30d/MTD leakage. Backend `range=Custom&from=2026-07-01&to=2026-07-31` inclusive (test-proven excludes 06-30/08-01). LIVE grids same period.

## 2. Headline KPIs (all 6 present, none omitted)
| Label | Rendered | Backend | LIVE | Verdict |
|---|---|---|---|---|
| GROSS SALES | — Not available | S&T not_synchronized (missing 07-01→07-19) | n/a (no S&T LIVE report) | HONEST NOT AVAILABLE |
| UNITS SOLD | — Not available / Not available (orders) | S&T not_synchronized | n/a | HONEST NOT AVAILABLE |
| NET REVENUE | £1,684 (+179.4%) | Settlements netRevenue 1683.86 | no LIVE Settlements report | UNVERIFIED |
| PPC SPEND | £1,016 | ppc-summary.adSpend 1015.58 | PPC-Campaigns 1015.58 | PASS (rounded) |
| NET PROFIT | £1,010 | premium.profit 1009.85 | P&L net_profit 1009.85 | PASS (rounded) |
| NET MARGIN | 26.5% | premium.marginPct 26.4677 | P&L margin 26.47 | PASS (rounded) |

## 3. Sales & revenue section
Chart + trend stats (AOV/Units-day/Sessions/Unit-session%) all "—" — correctly honest, since S&T source is `not_synchronized` for the FULL July range (leading-gap rule: missing 07-01→07-19 means the whole range is withheld, not partially served, per the documented hybrid leading/trailing coverage rule). DataDoe P&L separately holds Sales=3815.41/Units=231/Sessions=1816 for July, but the dashboard's Gross-Sales/Units/Sessions fields are explicitly S&T-sourced (confirmed via cost-table SOURCE column "Sales & Traffic by ASIN & Date · total_sales") — NOT substituted from P&L. This is a genuine dataset distinction, correctly not conflated.

## 4. Cost breakdown / waterfall — every line traced
| Line | Rendered | Backend | Source (dashboard-displayed) | LIVE report exists? | Verdict |
|---|---|---|---|---|---|
| Gross sales | — Not available | S&T (empty) | Sales & Traffic · total_sales | no | HONEST N/A |
| Refunds & returns | −£49 | −48.67 | Settlements · refunded_amount | no | UNVERIFIED |
| Promotions & coupons | −£306 | −305.69 | Settlements · promotion/coupon | no | UNVERIFIED |
| Amazon referral fee | −£691 | −691.15 | Settlements · referral_fee | no | UNVERIFIED |
| FBA fulfilment fee | −£814 | −813.89 | Settlements · fba_per_unit_fulfillment_fee | no | UNVERIFIED |
| FBA storage | −£0 | 0 | Settlements · fba_storage_fee | no | UNVERIFIED |
| Aged/long-term storage | −£0 | 0 | Settlements · long_term_storage_fee | no | UNVERIFIED |
| Other Amazon fees | −£0 | 0 | Settlements · amazon_fees | no | UNVERIFIED |
| PPC ad spend | −£1,016 | 1015.58 | Ad Performance · ad_spend | **yes — PPC-Campaigns 1015.58** | **PASS** |
| Cost of goods | −£0 | manual, none entered | Manual entry · cost per SKU | n/a | correct (no data entered) |
| Inbound freight & duty | −£0 | manual | Manual entry | n/a | correct |
| Return processing | −£0 | Settlements combo field | Settlements | no | UNVERIFIED |
| Net profit | £1,010 | 1009.85 | DataDoe · Profit & Loss · net_profit | **yes 1009.85** | **PASS** |

Individually verified, not assumed correct merely because the final Net Profit matched.

## 5. Breakdown mode: Period total vs Per unit — GENUINE recalculation, proven
Before (Period total): AMOUNT column shows £ figures (−£49, −£306, … £1,010). After clicking "Per unit": EVERY cost-line's AMOUNT and PER-UNIT cell switched to honest "—" (not £0, not stale value) because Units Sold is unavailable for July (S&T empty) — `perUnit()` correctly refuses to divide by an unavailable denominator. The waterfall bar chart above the table stays in £ (period-total) by design — it is not unit-scaled (confirmed in code: `waterfall` array built independent of `isUnit`). **This is a real, working control, not cosmetic** — restored to Period total after testing.

## 6. DataDoe Profit & Loss card — rendered, all 7 rows verified
| Row | Rendered | Backend | LIVE (fresh, this session) | Verdict |
|---|---|---|---|---|
| Sales | £3,815 | 3815.41 | 3815.41 | PASS |
| Advertising | −£1,219 | −1218.68 | −1218.68 (day-sum; MONTH-grid shows −1218.70, DataDoe-internal £0.02 rounding) | PASS |
| Amazon fees | −£1,432 | −1432.46 | −1432.46 | PASS |
| Refund cost | −£41 | −41.45 | −41.45 | PASS |
| FBA chargeback | −£115 | −114.97 | −114.97 | PASS |
| Lost/damaged | £2 | 2.00 | 2.00 | PASS |
| Net profit | £1,010 | 1009.85 | 1009.85 | PASS |
Source fields distinct from Profit-by-Date/Settlements/S&T/PPC — not mixed.

## 7. PPC section — every displayed metric
| Metric | Rendered | Backend | LIVE (fresh) | Displayed? |
|---|---|---|---|---|
| Ad spend | £1,016 | 1015.58 | 1015.58 | PASS |
| Ad sales | £1,848 | 1848.26 | 1848.26 | PASS |
| ACOS | 54.9% | 54.9479 | 54.9479 | PASS |
| TACOS | — Not available | needs Gross Sales (S&T empty) | n/a | HONEST N/A |
| CPC | £0.43 | 0.4278 | 0.4278 | PASS |
| Conversion | 4.7% | 4.6757 | 4.6757 | PASS |
| Clicks / Impressions / Orders / CTR / ROAS | **NOT DISPLAYED anywhere** (confirmed via full-page text search) | present in backend (2374/624183/111/0.3803/1.8199) | present in LIVE | NOT DISPLAYED |
Filter confirmed = SPONSORED_PRODUCTS only (42 campaigns, matches LIVE SP-only aggregate exactly).

## 8. Live Products — 45 cards inspected
- 45 product cards rendered (union of Profit-by-SKU 42 ASINs + Product-Catalog 5 ASINs, some overlap).
- Images: 45 `<image-slot>` elements, only **5 have a real `src`** (from `m.media-amazon.com`, matching the 5-row Product-Catalog cache exactly); the other 40 honestly show "Drop an image" placeholder — **no mock/fake image ever substituted**.
- Spot-checked B0B9MGR6C8: REVENUE £1,066 (←1066.36) / NET MARGIN 47.5% (←47.4718) / AD SPEND £147 (←147.37) / ACOS 21.6% (←21.5573) — fresh backend read this turn, exact match.
- Price/units/BSR/Buy Box/stock: honestly "—"/"Not available" where the source (Listings price, S&T units, Catalog BSR) doesn't cover that ASIN — never coerced to £0/0.
- Card count: capped by the union of the two backend sources actually loaded (42+5, de-duplicated) — no arbitrary display truncation beyond that.

## 9. Product Listings — CRITICAL finding, full trace
**Dashboard shows: "Active 13 · of 100 loaded", badge "13% active".**

Trace: DataDoe Listings source (`amazon_listings_with_cogs`) → `getSellerSourceData({sourceName:"Listings", page, pageSize})` (exact-key, snapshot path, NOT `all:true`) → default `pageSize=100` when unspecified (`amazon-catalog.service.ts:359-362`) → `createExport({skip:(page-1)*pageSize, limit:pageSize})` — **DataDoe's export API itself is asked for only `skip:0, limit:100`**, i.e. the export request itself caps the returned rows to 100; no "fetch all, slice locally" occurs → `getSellerListings` controller → `GET /api/sellers/:id/listings` → **frontend hardcodes `pageSize=100`** (`fetch(base + '/listings?pageSize=100')`, index.html:1043) and never requests page 2 → `realListings` (100 rows) → `listingsActiveCount = realListings.filter(status==='Active').length` = **13** → rendered "Active 13 · of 100 loaded".

Findings:
- (A) Local cache: exactly **one** cache file for Listings (`5176e2d5a8…json`), page=1/pageSize=100, 100 rows, retrievedAt 2026-08-28 (stale). No page-2 file exists anywhere locally.
- (B) Backend returns exactly the 100 rows it has cached — correctly, not fabricated.
- (C) DataDoe's TRUE total listing count is **unknown** — no `totalResults`/`totalPages`/`hasNextPage` field exists anywhere in the cached response or the DataDoe export API contract observed.
- (D)–(E) confirmed: no pagination metadata present at all.
- (F) confirmed: `pageSize=100` (frontend-hardcoded) is the limiting factor.
- (G) confirmed: pagination beyond page 1 is **not implemented** — the frontend never requests further pages.
- (H) "13" = Active listings **among the 100 loaded rows** (NOT claimed as all-listings total) — the label "of 100 loaded" is itself honest about this cap.
- (I) The user-reported "60+ active listings" figure's source (Seller Central vs DataDoe vs elsewhere) cannot be determined from local data.
- (J) Duplicate check: 0 duplicate `listing_id` among the 100 rows.
- (K) Inactive listings ARE included in the 100 (76 Inactive, 13 Active, 11 Incomplete within the loaded page) — the page is not status-filtered.
- (L) Marketplace: all 100 rows are `marketplace_country_code: GB` — correctly single-marketplace-scoped.
- This section uses `from:null, to:null` in cache — a **current-state snapshot, NOT July-date-scoped** (does not change with the July date selector).

**Verdict: UNVERIFIED.** The displayed value is an honest, correctly-computed count of Active listings within the 100 rows actually loaded (backend=local=dashboard agree exactly: 13). But whether 100 rows represents the seller's FULL listing population cannot be confirmed or denied from any local data — no total-count field exists. **Not called PASS.** To determine ground truth: fetch page 2+ (or a larger pageSize up to MAX_PAGE_SIZE=500) — this requires a NEW DataDoe export (not covered by the existing cached page=1 key) — **STOPPED, not executed** (would need explicit authorization per protocol).

## 10. Import cost CSV — tested safely, genuinely functional
Verified via a synthetic 3-row CSV dispatched through the real file-input `change` handler (in-memory `state.costs` only — no backend write, no persistence, confirmed no CSV endpoint exists anywhere in the backend):
- Row 1 (valid ASIN + cost + freight) → imported.
- Row 2 (malformed ASIN "BADASIN") → correctly rejected, `badAsin` counter incremented, reported in the UI message.
- Row 3 (valid ASIN, non-numeric cost, valid freight) → partially applied (freight only) per the documented per-field validation — correct, not silently dropped or coerced to 0.
- UI message: **"Imported 2 SKU costs (0 apply to this range) · 1 skipped: bad ASIN"** — the "0 apply" is honest, because July's per-ASIN Sales & Traffic data (`realByAsinAll`) is empty (matches the S&T gap), not a CSV-import defect.
- No fake success state. State reset via page reload after test (test data was never persisted anywhere).

## 11. Empty/blank UI sweep
Full-page text scan for `undefined`, `NaN`, `Infinity`, `[object Object]`, `{{`/`}}`, and broken `<img>` (naturalWidth 0): **zero hits.** Every unavailable value renders as an honest "—"/"Not available", never a fabricated number.

## 12. Local data availability for the one open item (Listings)
Checked: `.cache/datadoe/5176e2d5a8….json` (the only Listings cache file), `.cache/datadoe/*.cov.json` (none are Listings — Listings is snapshot/exact-key, not coverage-based), `raw/` (no raw archive exists for this Listings export — predates raw-archiving). **No local file contains more than 100 Listings rows or any total-count metadata.** Reconstruction from existing local data is impossible. Minimum to resolve: re-fetch Listings with a larger `pageSize` (up to 500) or paginate to page 2+ — both require a fresh DataDoe export (source `ba689c05d7`, `amazon_listings_with_cogs`) — cost ≈1 token per page/size fetched. **Not executed.**

## 13–14. No code changes made this audit. Evidence stored: screenshots of July date-range header, Per-unit toggle before/after, PPC+Inventory+Listings row, LIVE P&L grid (fresh, Day interval), LIVE PPC-Campaigns grid; this file.

## FINAL JULY STATUS
Every metric that is BOTH displayed AND has a corresponding LIVE DataDoe report matches exactly (PPC 5 metrics + cost-line "PPC ad spend", P&L 6 components + Net Profit, headline Net Profit/Margin/PPC Spend) — **zero mismatches found anywhere in the entire dashboard.** However Net Revenue, all Settlements-sourced cost lines, Profit-by-SKU product-card financials, and — critically — **Product Listings "Active" count's representativeness of the full population** are **UNVERIFIED** (no LIVE report / no total-count data locally). Because UNVERIFIED items exist, overall status is **NOT PASS**.

---

## 2026-08-31 — FIX: Period total / Per unit control now governs the whole Breakdown section (frontend-only)

**Proven defect (behaviour, not data):** The "Period total / Per unit" toggle is positioned in the "Breakdown mode" section header, above BOTH the waterfall chart and the detail table, but only the detail table's AMOUNT column responded to it — the **waterfall bar chart labels stayed period-total in both modes**. Proven on 30d (units=133): Period mode waterfall £1,755/−£90/−£1,012/…/£1,150; clicking "Per unit" left those labels unchanged while only the table recalculated (−£90→−£0.68 etc.). A user judging the control by the chart would conclude it did nothing. Secondary honesty issue: in Per-unit mode when units are unavailable (e.g. July), the table AMOUNT rendered a misleading "**−—**" (negative-dash) instead of a bare "—".

**Root cause:** `waterfall` (frontend `index.html`) built its label text (`textAmt`/`amt`) always via `money()`/`neg()` — never referencing `isUnit`; and `isUnit` was defined *after* the waterfall. The table cost-row did `'−' + perUnit(c.amt)`, producing "−—" when `perUnit()` returned "—".

**Fix (frontend/index.html only, 3 edits, no backend/Sync/Export/hardcode):**
1. Moved `const isUnit` before the charts and added `const perUnitNeg = n => { const s = perUnit(n); return s === '—' ? '—' : '−' + s; }`.
2. Waterfall labels now switch to per-unit when `isUnit` (Gross/Net use `perUnit()`, cost rows use `perUnitNeg()`). Bar HEIGHTS unchanged — they are proportions of gross sales, so dividing every value by the same unit count preserves ratios; only £ labels change.
3. Detail table cost row uses `perUnitNeg(c.amt)` → renders "—" (not "−—") when units unavailable.

**Verified after fix (reloaded):**
- 30d Per-unit: waterfall + table both recalculate — Gross £13.19, Refunds −£0.68, referral −£2.45, FBA fulfilment −£3.86, PPC −£7.61, Net profit £8.65 (= period ÷ 133 units). ✓
- July Per-unit: waterfall + table both "—" (units unavailable), `−—` eliminated (page scan: 0 occurrences). ✓
- 30d & July Period-total: unchanged (£1,755/…/£1,150 and −£49/−£306/−£691/−£814/−£1,016/£1,010). ✓ No regression.
- July headline/PPC/P&L card values all unchanged; zero undefined/NaN/{{/−— leaks.

**Other controls/sections re-checked this pass — no change needed (already correct):**
- **Import cost CSV**: real, working implementation (`onCsvFile` FileReader handler; header-driven ASIN/cost/freight detection; validates + honestly reports skipped rows; feeds `state.costs`). NOT removed.
- **Active listings "13 of 100 loaded"**: honest — 13 Active among the 100 cached rows; `pageSize=100` frontend cap; no total-count field exists in DataDoe response/cache to prove the full population. Displayed count NOT changed (correct as-is).
- **Gross Sales / Units (July)**: "Not available" (S&T `not_synchronized`, leading gap 07-01→07-19) — does NOT show a partial value. Correct.
- **PPC £1,016 ← 1015.58 (LIVE SP)** and **Net profit £1,010 ← 1009.85 (LIVE P&L)** re-confirmed fresh vs LIVE this turn — exact MATCH.

---

## 2026-08-31 — FINAL PASS: Breakdown waterfall empty-state fix (frontend-only) + phase decisions

**Proven defect (Phase 4 — the "chart not working correctly"):** For July, Gross Sales (Sales & Traffic) is `not_synchronized`, so `hasPositiveGross=false` → `scale=0` → every waterfall bar collapsed to its 3-4px floor height inside a fixed 250px-tall container, producing a **large empty/unprofessional chart window** with a thin strip of bars at the bottom. Root cause: the waterfall is a "gross→net" cascade that scales bar heights by gross sales; with no gross-sales basis it cannot be drawn.

**Fix (frontend `index.html` only, no backend/Sync/Export/hardcode):**
- Added render props `waterfallReady: hasPositiveGross` and `waterfallUnavailable: !hasPositiveGross`.
- Template: gated the 250px bar chart + label row inside `<sc-if waterfallReady>`; added a compact honest empty-state (`<sc-if waterfallUnavailable>`) — a dashed card with warning icon: "The gross→net cost cascade needs **Gross sales** (Sales & Traffic) as its starting point, which isn't synchronised for this period. Every cost line is still shown, with its exact amount and source, in the itemised table below." The itemised detail table is unchanged and always shown.

**Verified (reloaded):**
- July (gross unavailable): empty 250px container GONE (0 present); honest message shown; detail table intact (Gross —, Refunds −£49, Promotions −£306, referral −£691, FBA fulfilment −£814, PPC −£1,016, Net profit £1,010). ✓
- 30d & August (gross available £1,755 / £1,797): waterfall renders normally with real varied bar heights (232/11.6/44.8/69.8px…), NO message. ✓ No regression.
- July headline/PPC/P&L card unchanged (Net Profit £1,010, PPC £1,016, P&L Sales £3,815…); zero undefined/NaN/{{ }}/−— leaks.

**Phase decisions (no change — already correct):**
- **Phase 3 Import cost CSV**: real, working implementation (`onCsvFile` FileReader; header-driven ASIN/cost/freight column detection; validates finite ≥0; rejects malformed ASIN; honestly reports skipped rows; merges into `state.costs` feeding the profit model). It is functional with a genuine workflow → **NOT removed** (removing working functionality would violate the preserve-working rule).
- **Phase 5 Period/Per-unit**: fixed in the prior pass (waterfall + table both recalculate; per-unit divides by units; honest "—" when units absent). Re-confirmed.
- **Phase 7 Live Products**: 45 cards; 5 real catalog images (m.media-amazon.com), 40 honest "Drop an image" labelled placeholders (an intentional interactive empty state, not a raw blank); financials render real or honest "—". No blank/broken windows remain after the waterfall fix.
- **Phase 8 Active listings "13 of 100 loaded"**: root cause PROVEN = `pageSize=100` (frontend-hardcoded) → export capped at 100 rows (`createExport skip:0 limit:100`) → 13 Active among the 100 cached rows (76 Inactive/11 Incomplete); DataDoe `listing_status` definition (may differ from Seller-Central "active"); no `totalResults`/`totalPages` field exists anywhere in the response/cache. The displayed count is honest **for its stated scope** ("of 100 loaded"). The seller-wide true active count is **UNVERIFIED** — obtaining it needs a fresh Listings export at a larger pageSize (≤500), which would also break the currently-working cached section until a Sync. Per the no-Export/no-Sync rule, **not executed; count NOT changed** (never fabricated to 60+).

Tests after fix: `npm test` 92/92 · `reconciliation-datadoe-ui.test.js` 19/19 · `pnl-components.test.js` 20/20. DataDoe export=0 · Sync=0.

---

## 2026-08-31 — PASS: Active-listings scope-honesty fix (frontend-only) + Import-CSV re-confirmed functional

**Active listings (Phases 1/5) — root cause PROVEN + FIXED.** Listings cache `5176e2d5a8…json`: `page=1, pageSize=100, rowCount=100` → **rowCount === pageSize (cap hit)**, so the export returned exactly the 100-row page-1 cap and more listings almost certainly exist beyond it. `listing_status` distribution in the loaded 100: Active 13 / Inactive 76 / Incomplete 11. **No other local source carries `listing_status`** (Settlements/S&T/Profit-by-SKU hold ASINs-with-activity, not listing status; max distinct ASINs=72), and this source exposes **no totalResults/hasNextPage** → the seller-wide active count is **not derivable locally**. Trace: Listings source `amazon_listings_with_cogs` → `getSellerSourceData` (exact-key snapshot, `pageSize=100`) → `createExport(skip:0,limit:100)` → cache 100 rows → `getSellerListings` → `/api/sellers/:id/listings` → frontend `fetch('/listings?pageSize=100')` (index.html) → `realListings` → `listingsActiveCount=13` → rendered.

FIX (frontend `index.html` only, no hardcode/Export/Sync): added `listingsCapped = listingsFetchedCount >= 100` (the requested pageSize). When capped: the "Active" sub-label became **"in first 100 loaded · more not synced"** (was "of 100 loaded") and the header badge became **"13 of 100 loaded"** (was "13% active"). The count 13 is unchanged (it is the real active count within the loaded set) but is no longer presented as the seller's total — the scope is now explicit. Verified rendered: badge "13 of 100 loaded", sub "in first 100 loaded · more not synced". **UNVERIFIED** (seller-wide true active count needs a fresh Listings export at pageSize≤500 or paging — withheld per no-Export rule; never fabricated to 60+).

**Import cost CSV (Phase 2) — re-tested fresh this turn, KEPT.** Dispatched a synthetic 3-row CSV through the real file input on 30d (has unit data): result "Imported 3 SKU costs (1 apply to this range)" and "Entered costs cover 3% of units sold" — proving the full chain CSV→parse→validate→`state.costs`→cost-coverage calc→UI works end-to-end. It is functional with a genuine workflow → **NOT removed** (removing working functionality would be wrong).

**Live Products (Phase 4)**: 45 cards; catalog-imaged cards show real title/ASIN/financials; imageless cards show the labelled "Drop an image" interactive placeholder (an intentional empty-state, not a blank/broken window) + ASIN + real financials or honest "—". No undefined/NaN/blank. No change needed.

**Breakdown (Phase 3)**: re-confirmed July shows the honest empty-state (0 tall empty chart containers, message present) and the detail table; per-unit recalculates on periods with units (proven 30d prior). Preserved.

Regression (July, this turn): Net Profit £1,010, Net Margin 26.5%, PPC £1,016/£1,848/54.9%, P&L card £3,815/−£1,219/−£1,432/−£41/−£115/£2/£1,010 — all unchanged; 0 leaks. Tests: npm test 92/92 · reconciliation 19/19 · pnl-components 20/20. Export=0 · Sync=0.

---

## 2026-08-31 — FINAL July audit: Active-listings ROOT CAUSE fully proven via token-free DataDoe tableStatistics (766 total)

Fresh LIVE (July settled/immutable, re-read this pass): PPC SP spend 1015.58 / sales 1848.26 / clicks 2374 / impr 624183 / orders 111 / ACOS 54.9479 / CPC 0.4278 / CVR 4.6757 (age 26s). P&L Sales 3815.41 / Advertising −1218.68 / Amazon fees −1432.46 / Refund cost −41.45 / FBA chargeback −114.97 / Lost/damaged 2 / Net profit 1009.85 / Margin 26.47 / Units 231 / Sessions 1816. All == localhost (rounded).

**ACTIVE LISTINGS — definitive root cause (Phase 6), token-free, no Export/Sync:**
The DataDoe app exposes per-source row counts in the seller's `sellerCentralConnection.tableStatistics` (read token-free from the app React Query `["contexts"]` cache). For Vertex trading UK:
- `amazon_listings_with_cogs` → **rowCount 766** (also `amazon_listings_raw` 766).
So the DataDoe listings source holds **766 listings** for this seller. The localhost Listings cache (`5176e2d5a8…json`) holds only **100** (page 1, `pageSize=100`, `rowCount === pageSize` = cap hit). 13 of those first 100 are `listing_status === 'Active'` (76 Inactive, 11 Incomplete). **The other 666 listings — and their active count — are never fetched locally** (frontend `fetch('/listings?pageSize=100')` + backend `createExport(limit:100)`; no pagination). The seller's reported "60+ active" is fully consistent with 766 total listings whose active ones are spread beyond the first 100.
- The TRUE seller-wide ACTIVE count is **UNVERIFIED**: it is not in local data (only 100 rows cached), `tableStatistics` gives total rowCount (766) not an active-status count, and this total is NOT exposed by the localhost backend (`/api/sellers/:id` has no `tableStatistics`; sellerCentralConnection null). Deriving the true active count needs the actual `listing_status` of the remaining 666 rows → a fresh Listings export (source `ba689c05d7` `amazon_listings_with_cogs`, pageSize up to 500 / all pages), ~1–2 tokens. **STOPPED before export per the no-Export rule.** The dashboard label already reads honestly: "Active 13 · in first 100 loaded · more not synced" — it never claims 13 is the total (and 766 cannot be shown without hardcoding, which is forbidden, or a backend seller-stats fetch that is out of scope and still would not yield the active count).

**Breakdown Period/Per-unit (Phases 5) — re-proven fresh with manual calcs (30d, units=133):** Period AMOUNT ÷ 133 = PER UNIT exactly — Refunds £90→£0.68, Referral £326→£2.45, PPC £1,012→£7.61; %gross = amount÷£1,755 gross (5.1%/18.6%/57.7%). Switching to Per-unit recalculates the AMOUNT column AND the waterfall labels to those per-unit values (Gross £13.19). Genuine calculation change, not cosmetic. July (no units) correctly shows "—" + honest empty-state.

**Live Products (Phase 7):** image-slots on-view = 5 real catalog images (m.media-amazon.com, load OK), 0 broken `<img>`; the rest are labelled "Drop an image" empty-states + ASIN + real financials or honest "—". No blank/broken/undefined. **Import cost CSV (Phase 8):** functional (fresh test prior pass imported 3 SKU costs / 1 applied / 3% coverage) → kept.

No code changes this pass (listings label already honest from the prior pass; the 766 finding confirms it). Tests: npm 92/92 · reconciliation 19/19 · pnl-components 20/20. Export=0 · Sync=0. Leaks=0.

---

## PASS N+1 — 2026-08-31 (later) — third consecutive full-audit request, genuinely re-fetched (no reuse)

Fresh hard-reload of both the LIVE DataDoe tab (full page navigate, not just a re-query) and localhost (new tab, `?jul3=verify`, date selector reset to default 30d then explicitly re-set to Custom 2026-07-01→2026-07-31 via `input[type=date]` + "Apply range").

**LIVE P&L (React Query cache, dataUpdatedAt age 9s at read):** rowCount 31 · Sales 3815.41 · Advertising −1218.68 · Amazon fees −1432.46 · Refund cost −41.45 · FBA chargeback −114.97 · Lost/damaged 2.00 · Net profit 1009.85 · Units 231 · Sessions 1816. **Identical to every prior read.**

**LIVE PPC-Campaigns (age 11s):** 44 campaign rows (SP) · spend 1015.58 · sales 1848.26 · clicks 2374 · impressions 624,236 · orders 111 · units 118 · ACOS 54.9479 · CPC 0.4278 · CTR 0.3803 · CVR 4.6757 · ROAS 1.8199. Matches prior read to the penny on every dashboard-displayed metric (spend/sales/ACOS/CPC/CVR). Note: impressions read 624,236 here vs 624,183 in the pass-N read and campaign-row count 44 vs "42" noted earlier — a few extra low-volume campaign rows/impression ticks on DataDoe's side between reads; **neither impressions nor campaign count is displayed on localhost**, so this has zero effect on any verified dashboard value.

**LIVE report tab list (fresh DOM read):** exactly 7 tabs — Profit & Loss, PPC–Products, PPC–Campaigns, PPC–Targeting and Search Terms, Inventory, Orders, SQP. **Confirmed again: no Sales & Traffic / Settlements / Listings / Profit-by-SKU tab exists.**

**LIVE `tableStatistics` (fresh, age 46s):** `amazon_listings_with_cogs` rowCount **766** (also `amazon_listings_raw` 766) — identical to prior finding.

**Localhost fresh full-page inventory (get_page_text after explicit July re-select):** Headline GROSS SALES/UNITS SOLD "Not available"; NET REVENUE £1,684; PPC SPEND £1,016; NET PROFIT £1,010; NET MARGIN 26.5%. Cost-breakdown 8 lines unchanged (−£1,016/−£814/−£691/−£306/−£49/−£0/−£0/net £1,010). DataDoe P&L card: £3,815/−£1,219/−£1,432/−£41/−£115/£2/£1,010 — all seven lines present and correct. PPC card: £1,016/£1,848/54.9%/—/£0.43/4.7% + 3 "campaigns burning margin" rows unchanged. Live Products: 45 SKU cards, revenue/margin/ad-spend/ACOS per card unchanged, "Not available" placeholders honest (no fabricated titles/images). Product listings: "13 of 100 loaded" / "Active 13 · in first 100 loaded · more not synced" — unchanged, still honest.

**Breakdown Mode fresh toggle test on July 1–31 specifically (not 30d):** clicked "Per unit" — AMOUNT column for every cost line (Refunds, Promotions, Referral fee, FBA fulfilment, PPC, Gross sales, Net profit) switched from period-total values (−£49, −£306, −£691, −£814, −£1,016, £1,010) to honest "—" across the board, because July has no units figure (Gross Sales/S&T unavailable → units unknown) — **the toggle genuinely re-renders the AMOUNT column state-driven, not a static/cosmetic label swap**; clicked back to "Period total" and the £ values returned exactly as before. Empty-state message (Gross sales needs S&T) still shown; itemised table still fully populated below it.

**Import cost CSV (fresh DOM check):** `<input type="file" accept=".csv,text/csv">` present and wired to an "Import cost CSV" control — genuinely functional, kept.

**Live Products images (fresh):** 1 `<img>` tag in the initially-rendered viewport (others load on scroll/lazy), 0 broken (`naturalWidth===0`) — consistent with prior full-scroll finding of 5 real images / rest honest placeholders.

**Regression (freshly re-run, not cited from memory):** `npm test` → **92 passed, 0 failed**. `reconciliation-datadoe-ui.test.js` → **19/19 passed** (incl. "Dashboard Net Profit == DataDoe P&L net_profit £1,009.85 (July, archived)", "Dashboard Net Margin == DataDoe P&L margin 26.47% (July)"). `pnl-components.test.js` → **20/20 passed** (July + August identity, regression guard July net profit still 1009.85).

**No proven defect found this pass → no code changes.** Export=0 · Sync=0 · Leaks=0. This confirms, on a third independent fresh-evidence pull, that every directly-verifiable July value is stable and matching LIVE, and that the remaining UNVERIFIED sections (Net Revenue/Settlements lines/S&T Gross-Sales-Units-Sessions/Profit-by-SKU/true active-listings count) remain unverifiable for the same structural reason (no LIVE Reports-UI report, or a withheld export) — not due to any new issue.

---

## PASS N+2 — 2026-08-31 (later) — UI/UX RESTRUCTURE authorized (Product Listings redesign + dead-UI removal)

User explicitly authorized functional + UI/UX restructuring for a production-ready dashboard. Investigated Priority-1 (Active Listings 13-vs-60+) at the record level and **fixed the presentation using only local data** (no Export/Sync).

**Root-cause re-confirmation at the source-field level (local cache `5176e2d5a81287879fcb4876886bbdd8f1064dd2.json`, 100 rows):**
- `listing_status` breakdown of the loaded page: **Active 13 · Inactive 76 · Incomplete 11** (sums to 100).
- All 100 rows: `marketplace_country_code = GB`, `seller_name = Vertex trading UK`, `marketplace_seller_id = A9RLF2AXS8EQP`, **0 duplicate `listing_id`**. So NOT a marketplace/seller/dedup/status-mapping/date bug.
- Cache metadata: `page:1, pageSize:100, rowCount:100` → **rowCount === pageSize = cap hit** = the loaded set is a PARTIAL page. The cache carries no total-row count / hasNextPage field, so the seller-wide total is not derivable locally (DataDoe app `tableStatistics` shows 766 total, but that lives on app.datadoe.com, not in any localhost source — surfacing it would require hardcoding an inferred value or a new DataDoe call, both disallowed).
- **Cause = the 100-row pagination cap only.** Frontend `fetch(/listings?pageSize=100)` + backend `createExport(limit:100)`, single page, no pagination.

**FIX (frontend `index.html`, 5 edits — data-driven, no hardcoded business values):**
1. Compute `listingsInactiveCount` (76) and `listingsIncompleteCount` (11) from the real `listing_status` field.
2. Rebuilt the listings tiles from `Active / Buy Box / Suppressed / Stranded` to **`Active / Inactive / Incomplete / Buy Box`** — the two dropped tiles ("Suppressed"/"Stranded") were permanently `—` for this source (this Listings source never populates them) = dead UI; replaced with the genuinely-populated status breakdown. Each status tile carries an explicit `of 100 loaded` scope suffix so no count reads as a seller total.
3. Added an amber **partial-coverage banner**: "Partial view — the first 100 listings (page 1) are loaded. The DataDoe listings source holds more than this; the rest are not synced locally, so the counts below describe the loaded page, not the seller’s full catalogue. Press "Sync data" to load them all." (Complete-state message when a future non-capped page loads.)
4. Header badge changed from a bare "13 of 100 loaded" to **`Partial · 100 loaded`** (or `Complete · N listings`) — states coverage completeness directly.
5. Gated the always-empty **"Blocking revenue now"** sub-section behind `hasListingIssues` (its `listingIssues` array is a hardcoded `[]` with no data pipeline) — removes a dangling empty header + border = a blank-UI-state fix.

**Rendered result verified fresh (localhost, both 30d and July views):** header `Partial · 100 loaded`; amber banner present; `Active 13 (green) / Inactive 76 / Incomplete 11 (amber) / Buy Box`. Identity 13+76+11 = 100 ✓. Buy Box shows 75.1% on 30d (S&T buybox_percentage synced) and honest `— / Not available` on July (S&T not synced for July — same honest basis as all other July S&T metrics). No dangling "Blocking revenue now" header. Screenshot: `screenshot-1788175951194-36.jpg`.

**Regression after fix (fresh):** `npm test` 92/92 · `reconciliation-datadoe-ui.test.js` 19/19 · `pnl-components.test.js` 20/20. Full July re-render confirms every untouched section intact: headline (Net Rev £1,684 / PPC £1,016 / Net Profit £1,010 / Margin 26.5% / Gross-Units "Not available"), cost-breakdown 8 lines, Breakdown honest empty-state + itemised table, DataDoe P&L card (£3,815/−£1,219/−£1,432/−£41/−£115/£2/£1,010), PPC card (£1,016/£1,848/54.9%/£0.43/4.7%), Live Products (real images + honest "Drop an image" placeholders, 0 broken), Import cost CSV (`<input type=file accept=.csv>` functional, kept).

**Data integrity:** no hardcoded values (766 deliberately NOT shown — it isn't in local data and inferring it is forbidden), no fabricated status, no forced matches, no relabelling to hide anything. The true seller-wide active count remains **UNVERIFIED** (needs the withheld Listings export) — but the UI now makes the partial scope unmistakable instead of implying 13 is the seller total. Export=0 · Sync=0.
