# DataDoe UI reconciliation — JULY 2026

Evidence captured directly from the DataDoe Reports UI (app.datadoe.com/reports) via Claude-in-Chrome.
Seller: **Vertex trading UK** (`19076074-9461-4eb0-a762-5f27185f9e5b`) · Marketplace: UK · Currency: **GBP**
Period: **2026-07-01 → 2026-07-31** · Comparison (UI auto): May 31 – Jun 30 · Interval: Day/Month (totals identical).
Retrieved: 2026-08-29. DataDoe export tokens spent this pass: **0** (UI reading only).

## A. Profit & Loss report (UI Total column)
| Metric | July value | Comparison (May31–Jun30) |
|---|---|---|
| Sales | £3,815.41 | £6,215.40 |
| Units | 231 | 314 |
| Refunds | 5 | 1 |
| Promo | £0.00 | £0.00 |
| Sponsored Products (ad) | −£1,218.68 | −£50.54 |
| FBA shipping chargeback | −£114.97 | −£81.14 |
| Giftwrap | £0.00 | £0.00 |
| Refund cost | −£41.45 | −£13.63 |
| Amazon fees | −£1,432.46 | −£1,663.31 |
| Lost/damaged by Amazon | +£2.00 | £3.30 |
| Gross profit | £1,009.85 | £4,410.08 |
| **Net profit** | **£1,009.85** | £4,410.08 |
| Estimated payout | £1,007.85 | £4,406.78 |
| TACOS | 31.94% | 0.81% |
| % Refunds | 2.16% | 0.32% |
| **Margin** | **26.47%** | 70.95% |
| ROI | 50,492.50% | 133,638.79% |
| **Sessions** | **1,816** | (prior 0) |

## B. PPC – Campaigns report (UI)
Per-campaign, July, columns SALES 140 / SPEND / CLICKS / IMPRESSIONS / UNITS 140 / ORDERS 140
(**14-day attribution**). Our local Ad-Performance cache reproduces the UI **to the penny** per campaign:
UY|SP|HRS|KW T £110.91/£374.75 · UY|SP|HRS|Auto £114.23/£224.85 · UY|SP|Facial Hair Removal|Auto £78.70/£91.96 ·
UY|SP|Callus Remover|Auto £20.73/£0 · SS|SP|Overnight Mask|Auto £20.36/£59.28. SP total (our cache, ex-VAT)
= spend £1,015.58 / sales £1,848.26.

## C. Orders report (UI)
Per-order transaction list (Amazon Order ID, Status Shipped/Cancelled, Date, Channel, Amount, COGS, Quantity,
City). Cancelled orders = £0.00/0 qty. This is the shipped/settled basis that aggregates into P&L Sales £3,815.41.

## D. Reconciliation vs our dashboard (July) + correct source per KPI
| Dashboard KPI | Our value | Correct DataDoe report | DataDoe value | Diff | Root cause / status |
|---|---|---|---|---|---|
| PPC spend | £1,015.58 | PPC-Campaigns (ex-VAT) | £1,015.58 | £0.00 | **PASS** (P&L "Sponsored Products" £1,218.68 = ×1.20 = +20% VAT, different report) |
| PPC sales | £1,848.26 | PPC-Campaigns (14-day attr) | £1,848.26 | £0.00 | **PASS** (per-campaign verified) |
| Net Profit | £1,142.28 | Profit by Date (source) | £1,142.28 | £0.00 | **PASS vs source**. P&L Net profit £1,009.85 differs (inc-VAT ad + fee treatment) — documented, not forced |
| Net Margin | 29.94% | Profit by Date | 29.94% | 0 | **PASS vs source** (P&L Margin 26.47%, diff basis) |
| Net Revenue | £1,683.86 | Settlements (total) | £1,683.86 | £0.00 | **PASS** (settlement/cash basis; no direct P&L line) |
| Gross Sales / Units / Sessions | "Not available" | Sales & Traffic | absent pre-07-20 | — | **PASS** — DataDoe itself lacks S&T pre-07-20 (P&L Sessions 1,816 = our 07-20..31 coverage). Honest unavailable, never £0 |
| Fee breakdown (referral/FBA/…) | as shown | Settlements | = source data | £0.00 | **PASS** |

**Verdict July: no source/mapping/calculation error.** Every KPI matches its correct DataDoe report. The
P&L-view differences are legitimate accounting definitions (20% VAT on ad; ordered-vs-shipped-vs-settled sales).
Per the rule "different reports, different definitions → document, don't force-match" — nothing is re-sourced.
