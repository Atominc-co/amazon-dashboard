# DataDoe ↔ Dashboard Reconciliation — July 2026 (2026-07-01 → 2026-07-31)

Generated: 2026-08-29. Seller: **Vertex trading UK** (`19076074-9461-4eb0-a762-5f27185f9e5b`), marketplace UK, currency GBP.
Method: metrics computed **independently** from the archived DataDoe rows in `backend/.cache/datadoe/*.cov.json`
(rows are stored verbatim = `JSON.parse` of the raw export payload), then compared to the live backend
response (`localhost:4000`, cache-only, **no `refresh`** → zero DataDoe tokens) and the rendered dashboard
(`localhost:8080`).

## DataDoe tokens spent this reconciliation: **1** (one targeted export — see "S&T gap RESOLVED" below)
All reconciliation reads were strict-local cache reads (verified: zero `datadoe.com` requests, zero
`refresh=1` params, backend responses in 3–5 ms). Exactly ONE controlled export was made — to answer,
definitively, whether DataDoe holds Sales & Traffic for 2026-07-01..07-19.

## S&T gap RESOLVED — DataDoe has NO Sales & Traffic before 2026-07-20 (proven)
Controlled export `e83fcb12-1ce8-441b-b81d-e36c6a6f49c7` (Sales & Traffic, from=2026-07-01, to=2026-07-19,
all rows) **COMPLETED successfully and returned `[]` (0 rows)**. This is not a 402/error — the source
genuinely contains no S&T rows before 2026-07-20 for this seller. Immutable audit record:
`backend/.cache/datadoe/raw/e83fcb12-…__f9918fec….json` (rawPayload `"[]"`, sha256 `4f53cda1…`).
Cache correctly recorded ZERO new coverage (no dated rows → intervals unchanged); 1067 rows preserved,
nothing fabricated, nothing dropped. **Conclusion: the dashboard's "Not available" for full-July gross
sales is definitively correct — the data does not exist upstream.** Do not re-probe this range (the
archived `[]` is proof enough for any future audit).

## Dataset → report → cache → endpoint map

| Dashboard section | DataDoe report (source id) | Cache file | Backend endpoint | Key metric(s) |
|---|---|---|---|---|
| Sales & revenue | Sales & Traffic by ASIN & Date (`401ffcd7e5`) | `60c14704….cov.json` | `/sales-summary` | Σ total_sales / total_units / total_orders / session |
| Settlements / P&L | Settlements & P&L Components (`732dac689a`) | `0c6ba485….cov.json` | `/financials-summary` | Σ total (net rev) + fee breakdown |
| Profit by Date | Profit by Date (`b24cd69c06`) | `480bd153….cov.json` | `/financials-summary-premium` | Σ profit, Σ total_sales, margin |
| Profit by SKU | Profit by SKU & Date (`57a0cb319c`) | `88e1c…` (dated) | `/sku-profit-summary` | per-ASIN Σ total_sales/profit/ad_spend |
| Ad Performance (PPC) | Ad Performance by Campaign & Date (`08cdc77d3d`) | `e3ada2b9….cov.json` | `/ppc-summary` | SP-only Σ ad_spend/ad_sales/clicks/impr/orders |
| Inventory (snapshot) | FBA Inventory by ASIN & Country | `2be11f33….json` (124 rows) | `/inventory` | latest-per-ASIN Σ quantity |
| Inventory Health (snapshot) | FBA Inventory Health | `f2e58e63….json` (189 rows) | `/inventory-health` | units-weighted days of cover |
| Listings (snapshot) | Listings | `5176e2d5….json` (100 rows) | `/listings` | active % |
| Product Catalog (snapshot) | Product Catalog by ASIN | `fa0e0a1c….json` (5 rows) | `/products` | image/price/BSR |

## Reconciliation table — July 2026

| Metric | DataDoe raw (independent) | Backend | Dashboard | Δ |
|---|---|---|---|---|
| **Sales & Traffic** — coverage | only 12/31 days (07-20..07-31); **07-01..07-19 MISSING** | `not_synchronized` missing 07-01..19 | "Not available" (—) | ✓ honest |
| Settlements — Net revenue (Σ total) | £1,683.86 | 1683.86 | £1,684 | £0 |
| Settlements — rows | 244 | 244 | — | 0 |
| Settlements — referral_fee | −£691.15 | −691.15 | −£691 | £0 |
| Settlements — fba fulfilment | −£813.89 | −813.89 | −£814 | £0 |
| Settlements — refunds | −£48.67 | −48.67 | −£49 | £0 |
| Settlements — promotions | −£305.69 | −305.69 | −£306 | £0 |
| Profit by Date — profit | £1,142.28 | 1142.28 | £1,142 | £0 |
| Profit by Date — total_sales | £3,815.41 | 3815.41 | (margin denom) | £0 |
| Profit by Date — margin | 29.94% | 29.94% | 29.9% | 0 |
| PPC — ad spend (SP) | £1,015.58 | 1015.58 | £1,016 | £0 |
| PPC — ad sales (SP) | £1,848.26 | 1848.26 | £1,848 | £0 |
| PPC — clicks / impressions / orders | 2,374 / 624,183 / 111 | same | same | 0 |
| PPC — ACOS | 54.95% | 54.95% | 54.9% | 0 |
| SKU-Profit — distinct ASINs / rows | 42 / 814 | 42 / 814 | 42 cards | 0 |

**Cross-source integrity checks (all pass):**
- Profit-by-Date `total_sales` £3,815.41 == Profit-by-SKU revenue £3,815.41 (same shipped-order basis)
- Ad-Performance SP `ad_spend` £1,015.58 == Profit-by-SKU `ad_spend` £1,015.58

## Result: ZERO calculation / mapping / aggregation defects found
Every displayed number traces cleanly `DataDoe row → cov.json → backend aggregation → controller → dashboard`.
No wrong report, wrong date field, timezone, boundary, duplicate, pagination, currency, or metric-mapping
error was found. Fabricated-zero behavior is correct: every value that isn't in the local cache renders
"Not available"/"—", never £0.

## The one gap (not a bug — a data-coverage gap)
Sales & Traffic local cache = **2026-07-20 → 2026-08-24**. July 1–19 was never synced, so under the
strict-local (sync-only) architecture, a full-July query correctly returns `not_synchronized` and the
dashboard honestly shows "Not available" for gross sales / units / sessions / AOV / TACOS / Buy Box.
The last-12-days partial (07-20..07-31) = **£1,139.30 / 79 units** (verified). Full-July gross sales would be
£1,139.30 **plus** whatever DataDoe holds for 07-01..07-19 — which we do not have locally.

**RESOLVED (see top):** a targeted one-export probe of exactly 2026-07-01..07-19 returned `[]` — DataDoe has
no data there. The gap is unfillable because the upstream source is empty for that range, not because of a
local omission. Full-July gross sales stays "Not available" and that is the correct, honest state.

## Test matrix (all cache-only, 0 tokens)

| Range | Sales & Traffic | Financials | Profit by Date |
|---|---|---|---|
| A July 01–31 | not_synchronized (07-01..19) | £1,683.86 | £1,142.28 |
| B July 20–31 | £1,139.30 / 79u | £599.96 | £272.78 |
| C Aug 01–28 | £1,796.61 PARTIAL (trailing) | £344.30 PARTIAL | £676.39 |
| D 30d | £1,836.47 PARTIAL | £371.04 PARTIAL | £678.27 PARTIAL |
| E 7d | £170.88 PARTIAL | −£457.30 PARTIAL | £13.18 PARTIAL |
| F MTD | £1,796.61 PARTIAL | £344.30 PARTIAL | £676.39 PARTIAL |
| G 2024-01 (out of coverage) | range_unavailable 422 | range_unavailable 422 | range_unavailable 422 |
| H 2025-06-20..28 (crossing start) | not_synchronized (leading) | not_synchronized | not_synchronized (06-20..23) |

Console: no errors. Network on date changes: localhost only, zero datadoe.com, zero refresh.

---

# August 2026 reconciliation + completion-loop audits (2026-08-29, 0 additional tokens)

## August — DataDoe rows = backend = dashboard (cache-only)
| Metric | Aug 1–24 (fully covered) | Aug 1–28 (partial, honest) |
|---|---|---|
| Gross sales (S&T) | £1,796.61 / 136u | £1,796.61 / 136u (S&T cached →08-24) |
| Net revenue (Settlements) | £855.28 | £344.30 (→08-27) |
| Net profit (Profit by Date) | £703.32 (margin 39.72%) | £676.39 (37.90%) |
| PPC SP spend / sales | £941.26 / £1,057.53 | £982.18 / £1,079.51 (→08-26) |
| Profit-by-SKU ASINs | 47 | 47 |
Backend == independent cache calc == dashboard (verified in browser: Gross £1,797, Net rev £344,
Net profit £676, Net margin 37.9%, PPC £982). Amber partial banner honestly names each source's
cutoff (S&T→08-24, Settlements→08-27, Ads→08-26). Today (08-29) never treated as a complete day.

## Completion-loop audits (all resolved without additional tokens)
- **PPC categories (§14):** SP-only is intentional and the UI is labelled "Sponsored Products".
  Excluded SB/SD quantified: July SB £0 / SD £0 (excludes nothing); Aug 1–24 SB £15.41 spend /
  £27.98 sales, SD £0.30 (negligible, honestly out of scope of the "Sponsored Products" label). No change.
- **Settlement duplicates (§15):** 112 exact-identical rows across 44 distinct dates. No stable
  transaction id exists, so rows must not be removed on value-identity alone. Proven legitimate:
  `mergeRowsForInterval` drops-then-appends by fetched interval, so it CANNOT create duplicates
  (DataDoe returns rows within the requested window) → the identical rows originate from DataDoe
  (identical units → identical fees → identical settlement lines). Removing them would understate
  July net revenue by £202.20. No change.
- **Per-ASIN completeness (§13):** Product cards are the union of Profit-by-SKU / Sales / Settlements
  ASINs (already de-limited from the old ≤5), each showing real REVENUE/MARGIN/AD SPEND/ACOS. Only
  catalogue *identity* metadata (name/image/BSR) is limited to the 5 synced Product-Catalog rows and
  correctly shows "Not available" + the ASIN — valid financial data is never hidden. `/products?pageSize=5`
  matches the cached snapshot key; raising it would MISS the cache. No change.
- **Fabricated-zero (§18):** every headline KPI value is `hasReal*`-gated → renders "—" when not real
  (grep found zero ungated currency emitters). `|| 0` fallbacks exist only in chart series (clipped to
  the covered extent) and sort keys, not KPI values. No change.
- **Date semantics (§8):** inclusive `[from,to]` on the row `date` (first 10 chars); confirmed in
  `filterRowsInRange`. Backend windows match the displayed header exactly.

## Code/UI changes this pass: NONE (no defect found). Backend restart: not required (no functional change).

---

# DataDoe WEB UI inspection (2026-08-29, app.datadoe.com/reports, seller Vertex trading UK, 0 export tokens)

Source of truth = the DataDoe Reports **Profit & Loss** view (interval Day). Values read directly from the UI grid.

## JULY 2026 — DataDoe P&L UI (Total column) vs our dashboard
| DataDoe P&L (UI) | July Total | Our dashboard (July) | Source of our number | Match |
|---|---|---|---|---|
| Sales | £3,815.41 | Gross Sales = "Not available" | Sales & Traffic total_sales (partial) | ✗ |
| Units | 231 | "Not available" | Sales & Traffic total_units (partial) | ✗ |
| Sponsored Products (ad) | −£1,218.68 | PPC spend £1,015.58 | Ad Performance SP | ✗ (−£203) |
| Amazon fees | −£1,432.46 | (fee breakdown, different layout) | Settlements | n/a |
| Refund cost | −£41.45 | Refunds −£48.67 | Settlements refunded_amount | ~ |
| Net profit | £1,009.85 | Net Profit £1,142.28 | Premium Profit by Date profit | ✗ (−£132) |
| Margin | 26.47% | Net Margin 29.94% | Profit by Date | ✗ |
| TACOS | 31.94% | "Not available" | (needs gross sales) | ✗ |
| Sessions | 1,816 | "Not available" | Sales & Traffic session | ✗ but PROVES point |
| Net revenue (no P&L line) | — | £1,683.86 | Settlements total | — |

## KEY UI-VERIFIED CONCLUSIONS
1. **DataDoe's P&L "Sessions" Total for July = 1,816 — identical to our S&T cache coverage of ONLY 07-20..07-31.**
   The DataDoe UI ITSELF has no Sales & Traffic / sessions / traffic data before 2026-07-20. Our
   "Not available" for gross sales/units/sessions/AOV/buybox is therefore CORRECT and matches the UI.
   (The empty S&T export for 07-01..19 was right.)
2. **DataDoe's P&L "Sales" = £3,815.41 for FULL July, and equals our Profit-by-Date total_sales EXACTLY**
   → same shipped/order-line basis; July 1-19 FINANCIAL data exists in DataDoe and we hold it. But our
   dashboard sources the "Gross Sales" KPI from the *Sales & Traffic* report (ordered-product-sales/traffic
   basis, partial) → shows "Not available" instead of the £3,815.41 the P&L UI shows.
3. **The July headline mismatches (Sales, Ad, Net profit, Margin, TACOS) are DEFINITIONAL** — our dashboard
   reads each KPI from a *different DataDoe report* (Sales&Traffic / Settlements / Profit-by-Date /
   Ad-Performance) than the unified P&L view aggregates. Each of our numbers is faithful to ITS source
   (internally 100% reconciled, proven earlier), but those sources don't equal the P&L report's numbers.
   The current per-source design is intentional & documented in code (bases deliberately not mixed).

## AUGUST 1–28 2026 — DataDoe P&L UI (Total)
Sales £2,001.84 · Units 150 · Refunds 4 · Advertising cost −£1,270.01 · FBA shipping chargeback −£29.37 ·
Refund cost −£78.71. Our Profit-by-Date Aug 1-28 cache total_sales = £1,784.85 (vs UI £2,001.84).
July (settled) matched to the penny; August differs because our cache is the **08-28 snapshot** while the
UI is **live (08-29)** — the recent mutable days accreted more data after our last sync = STALENESS, not a
definitional gap. A Sync (or targeted recent-window fetch) would close it.

## No code changed in this pass — the divergences are source-of-truth/definition decisions, surfaced for the user.

---

# PER-REPORT mapping — each dashboard KPI verified against its CORRECT DataDoe report (2026-08-29)

Rule followed: DataDoe reports legitimately differ from each other; map each KPI to its correct report,
document definitional differences, do NOT force one report to equal another (P&L is NOT auto-truth).

## Root cause of the P&L-vs-dashboard PPC gap = 20% UK VAT (PROVEN)
Our SP ad spend is EXACTLY 1.2000× lower than the P&L "Sponsored Products" every day:
  07-29 £30.49 vs £36.59 · 07-30 £33.24 vs £39.89 · 07-31 £21.88 vs £26.26 · total £1,015.58 vs £1,218.68 (×1.20).
→ PPC-Campaigns report & our Ad-Performance source = ad spend **ex-VAT** (media-spend/ACOS basis).
→ P&L "Sponsored Products" = ad spend **inc-VAT** (cash cost). Both DataDoe; different VAT treatment.
Per-campaign cross-check (our cache vs PPC-Campaigns UI, July): UY|SP|HRS|KW T £110.91/£374.75,
UY|SP|HRS|Auto £114.23/£224.85, UY|SP|Facial Hair Removal|Auto £78.70/£91.96, UY|SP|Callus Remover|Auto
£20.73/£0, SS|SP|Overnight Mask|Auto £20.36/£59.28 — ALL match to the penny. Our PPC is complete, not missing campaigns.
(DataDoe PPC uses 14-day attribution — "SALES 140".)

## Final per-KPI source map + verdict (July 2026)
| Dashboard KPI | Correct DataDoe report/source | Our value | DataDoe (correct report) | Verdict |
|---|---|---|---|---|
| PPC spend / ACOS | PPC – Campaigns (Ad Perf, ex-VAT) | £1,015.58 | matches per-campaign & daily | ✓ CORRECT (P&L £1,218.68 = +VAT, different report) |
| Net Profit | Profit by Date (source) | £1,142.28 | = its export data exactly | ✓ CORRECT (P&L £1,009.85 = inc-VAT ad + diff fees) |
| Net Margin | Profit by Date | 29.94% | consistent w/ above | ✓ CORRECT (P&L 26.47%, diff basis) |
| Net Revenue | Settlements & P&L Components (total) | £1,683.86 | = its data exactly | ✓ CORRECT (settlement/cash basis) |
| Gross Sales / Units / Sessions | Sales & Traffic by ASIN & Date | "Not available" | DataDoe lacks pre-07-20 (P&L Sessions=1,816=our 07-20..31 coverage) | ✓ CORRECT honest-unavailable |
| Fee breakdown (referral/FBA/etc.) | Settlements & P&L Components | as shown | = its data exactly | ✓ CORRECT |

## CONCLUSION: no genuine source/mapping/calculation ERROR found.
Every KPI faithfully reproduces its designated DataDoe report/source (PPC verified per-campaign AND
per-day to the penny; profit/margin/net-revenue verified vs their exports; gross-sales/sessions correctly
unavailable because the Sales & Traffic source genuinely lacks pre-07-20 data — confirmed in the DataDoe UI
itself). All divergences from the unified P&L view are legitimate, precisely-explained accounting definitions
(20% VAT on ad; ordered-vs-shipped-vs-settled sales bases). Per rule 18 these are documented, NOT force-matched.
No code changed. Only genuinely-actionable item: August recent-day STALENESS (our cache = 08-28 snapshot vs
live UI 08-29) — resolved by a normal Sync of the recent mutable window, not a code fix.

---

## FINAL LOCALHOST UI VERIFICATION — 2026-08-31 (backend↔rendered DOM; ZERO DataDoe/Sync/Export)

Method: live localhost dashboard (frontend :8080 → backend :4000, `node dist/server.js` PID 8652).
Backend values captured token-free via the summary endpoints WITHOUT `refresh` (all `cache.status:"cached"`).
Rendered values read from the actual DOM (`innerText`) + screenshots. Range set through the real Custom
date picker. Network inspected on the Aug range change: 5 localhost calls, `range=Custom&from&to`, **no
`refresh` param**, zero `api.datadoe.com`. No Sync/Export button ever pressed.

### JULY 2026-07-01 → 07-31

PPC (all displayed KPIs) — backend → rendered:
- Ad spend £1015.58 → **£1,016** ✓ | Ad sales £1848.26 → **£1,848** ✓ | ACOS 54.948% → **54.9%** ✓
- TACOS → **Not available** ✓ (needs S&T gross sales, leading-gap) | CPC £0.42779 → **£0.43** ✓ | CVR 4.6757% → **4.7%** ✓
- NOT RENDERED anywhere in UI: Clicks (2374), Impressions (624183), Orders (111), CTR, ROAS — no UI element exists (not a defect; backend field present, no tile).
- Campaigns burning margin: MIM|Him|3in1 £36/£7/518.0% ✓; LP|Heritage £70/£22/320.2% ✓; MIM|Gift Set £40/£21/192.5% ✓

P&L / "Where the money went" + headline — backend → rendered:
- Net Profit (DataDoe P&L net_profit) £1009.85 → **£1,010** ✓ | Net Margin 26.4677% → **26.5%** ✓ | totalSales £3815.41 (margin denom, embedded) ✓
- PPC ad spend −£1015.58 → **−£1,016** ✓ | FBA fulfilment −£813.89 → **−£814** ✓ | referral −£691.15 → **−£691** ✓
- Promotions −£305.69 → **−£306** ✓ | Refunds −£48.67 → **−£49** ✓ | FBA storage £0 → **−£0** ✓ | LT storage £0 → **−£0** ✓
- Net Revenue (settlements) £1683.86 → **£1,684** ✓ (+179.4% vs prior)

Sales & Traffic (trace-only, UNVERIFIED vs LIVE): backend `not_synchronized` (leading gap 07-01..07-19) →
UI **Gross Sales / Units "Not available"** + blue not-synced banner ✓ (rendering == backend source).

Profit by SKU (trace-only, UNVERIFIED vs LIVE) — 42 ASINs; spot-check backend → rendered:
- B0B9MGR6C8 rev £1066.36/mgn 47.47%/ad £147.37/acos 21.56% → **£1,066 / 47.5% / £147 / 21.6%** ✓
- B0B3RYSVD4 £564.61/18.94%/£193.63/61.51% → **£565 / 18.9% / £194 / 61.5%** ✓
- B0DTQ4CTCL £312.67/54.37%/£30.70/40.37% → **£313 / 54.4% / £31 / 40.4%** ✓
- B0DW487F1H £304.93/63.03%/£19.09/23.87% → **£305 / 63.0% / £19 / 23.9%** ✓

### AUGUST 2026-08-01 → 08-28

Headline — backend → rendered:
- Gross Sales £1796.61 → **£1,797** ✓ | Units 136 → **136** ✓ / 131 orders → **131 orders** ✓
- Net Revenue £367.07 → **£367** ✓ (−75.6%) | PPC £1044.23 → **£1,044** ✓ (+8.9%, TACOS 58.1%)
- Net Profit £1104.89 → **£1,105** ✓ (+48.8%) | Net Margin 51.4457% → **51.4%** ✓ (+28.4pt)

PPC (all displayed KPIs) — backend → rendered:
- Ad spend £1044.23 → **£1,044** (+8.9%) ✓ | Ad sales £1267.35 → **£1,267** (−21.6%) ✓ | ACOS 82.395% → **82.4%** (+23.1pt) ✓
- TACOS 58.1% ✓ | CPC £0.42796 → **£0.43** (−£0.00) ✓ | CVR 3.9754% → **4.0%** (−0.5pt) ✓
- NOT RENDERED: Clicks (2440), Impressions (707091), Orders (97), CTR, ROAS.
- Campaigns: LP|Brand KW £41/£8/515.3% ✓; FO|Skin Quench £46/£11/417.5% ✓; SS|Eye Patches £50/£13/384.7% ✓

P&L / "Where the money went" — backend → rendered (all ✓):
- PPC −£1044.23 → −£1,044 (58.1%) | FBA fulfilment −£540.21 → −£540 (30.1%) | referral −£347.19 → −£347 (19.3%)
- Promotions −£108.20 → −£108 (6.0%) | LT storage −£103.42 → −£103 (5.8%) | Refunds −£89.85 → −£90 (5.0%) | FBA storage −£64.58 → −£65 (3.6%)
- Net Profit £1,105 | Net Margin 51.4% ✓

Sales & Traffic (trace-only, UNVERIFIED vs LIVE) — partial (covered 08-01..08-24), backend → rendered:
- Gross Sales £1796.61 → £1,797 ✓ | AOV £13.7146 → £13.71 ✓ | Units/day 4.857 → 4.9 ✓ | Sessions 7012 → 7,012 ✓ | Unit-session% 1.9395 → 1.9% ✓
- Amber partial banner: "Sales & Traffic cached through 2026-08-24 … unavailable (never £0)" ✓ (rendering == backend coverage)

Profit by SKU (trace-only, UNVERIFIED vs LIVE) — 48 ASINs; spot-check backend → rendered:
- B0B3RYSVD4 £601.25/29.74%/£223.94/49.80% → £601 / 29.7% / £224 / 49.8% ✓
- B0DW487F1H £279.93/62.43%/£18.99/15.83% → £280 / 62.4% / £19 / 15.8% ✓

### RESULT
- Every directly-verifiable DataDoe section (PPC, P&L, headline Net Rev/Profit/Margin, Gross Sales) renders its exact backend value. Only transform = intentional presentation rounding (money = Math.round to whole £; %=1dp; per-unit/CPC/AOV=2dp). Presentation-only — raw backend numbers unchanged, no data mutation.
- Regression scan: rendered DOM has ZERO undefined/NaN/Infinity/[object Object]/{{ }} leaks; no console errors on range changes.
- **DataDoe API calls = 0 · Sync = 0 · Export = 0** (network-verified). **Zero code changes** — no discrepancy found, nothing to fix.
- S&T / Settlements / Profit-by-SKU: localhost rendering == local/backend source with no regression; they remain UNVERIFIED against LIVE DataDoe (no corresponding LIVE Reports-UI report) — NOT called PASS.
- FINAL: **PASS** for all directly-verifiable sections.
